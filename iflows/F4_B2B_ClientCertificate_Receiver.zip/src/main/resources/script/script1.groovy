import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.Instant

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader)
    def payload

    try {
        payload = new JsonSlurper().parse(reader)
    } catch (Exception exception) {
        throw new IllegalArgumentException(
            "Invalid JSON payload received from B2B partner."
        )
    }

    if (!(payload instanceof Map)) {
        throw new IllegalArgumentException(
            "The ASN payload must be a JSON object."
        )
    }

    def requiredFields = [
        "partnerId",
        "deliveryNumber",
        "purchaseOrder",
        "material",
        "quantity",
        "plant",
        "expectedDeliveryDate"
    ]

    def missingFields = requiredFields.findAll { field ->
        !payload.containsKey(field) ||
        payload[field] == null ||
        payload[field].toString().trim().isEmpty()
    }

    if (!missingFields.isEmpty()) {
        throw new IllegalArgumentException(
            "Missing or empty mandatory fields: ${missingFields.join(', ')}"
        )
    }

    def quantity

    try {
        quantity = new BigDecimal(payload.quantity.toString())
    } catch (Exception ignored) {
        throw new IllegalArgumentException(
            "Field quantity must be numeric."
        )
    }

    if (quantity <= 0) {
        throw new IllegalArgumentException(
            "Field quantity must be greater than zero."
        )
    }

    payload.quantity = quantity
    payload.receivedAt = Instant.now().toString()
    payload.authenticationType = "X509_CLIENT_CERTIFICATE"
    payload.integrationStatus = "ASN_ACCEPTED"

    message.setProperty(
        "partnerId",
        payload.partnerId.toString()
    )

    message.setProperty(
        "deliveryNumber",
        payload.deliveryNumber.toString()
    )

    message.setBody(
        JsonOutput.prettyPrint(
            JsonOutput.toJson(payload)
        )
    )

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}