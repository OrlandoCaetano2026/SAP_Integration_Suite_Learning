import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {

    Reader bodyReader = message.getBody(Reader)

    if (bodyReader == null) {
        throw new IllegalArgumentException(
            "SAP MM purchase order confirmation payload cannot be empty."
        )
    }

    def payload

    try {
        payload = new JsonSlurper().parse(bodyReader)
    } catch (Exception exception) {
        throw new IllegalArgumentException(
            "Invalid JSON received for SAP MM purchase order confirmation."
        )
    }

    if (!(payload instanceof Map)) {
        throw new IllegalArgumentException(
            "The purchase order confirmation payload must be a JSON object."
        )
    }

    def requiredHeaderFields = [
        "messageId",
        "creationDateTime",
        "senderSystem",
        "receiverSystem",
        "messageType"
    ]

    def requiredPurchaseOrderFields = [
        "ebeln",
        "bsart",
        "lifnr",
        "ekorg",
        "ekgrp",
        "bukrs",
        "waers"
    ]

    def requiredConfirmationFields = [
        "confirmationReference",
        "confirmationDate",
        "confirmationStatus",
        "items"
    ]

    validateSection(
        payload.messageHeader,
        "messageHeader",
        requiredHeaderFields
    )

    validateSection(
        payload.purchaseOrderHeader,
        "purchaseOrderHeader",
        requiredPurchaseOrderFields
    )

    validateSection(
        payload.purchaseOrderConfirmation,
        "purchaseOrderConfirmation",
        requiredConfirmationFields
    )

    String messageId =
        payload.messageHeader.messageId
            ?.toString()
            ?.trim()

    String ebeln =
        payload.purchaseOrderHeader.ebeln
            ?.toString()
            ?.trim()

    String lifnr =
        payload.purchaseOrderHeader.lifnr
            ?.toString()
            ?.trim()

    String confirmationReference =
        payload.purchaseOrderConfirmation
            .confirmationReference
            ?.toString()
            ?.trim()

    if (!(ebeln ==~ /\d{10}/)) {
        throw new IllegalArgumentException(
            "Field purchaseOrderHeader.ebeln must contain exactly 10 digits."
        )
    }

    if (!(lifnr ==~ /\d{10}/)) {
        throw new IllegalArgumentException(
            "Field purchaseOrderHeader.lifnr must contain exactly 10 digits."
        )
    }

    def items = payload.purchaseOrderConfirmation.items

    if (!(items instanceof List) || items.isEmpty()) {
        throw new IllegalArgumentException(
            "Field purchaseOrderConfirmation.items must contain at least one item."
        )
    }

    items.eachWithIndex { item, index ->

        def requiredItemFields = [
            "ebelp",
            "matnr",
            "werks",
            "lgort",
            "menge",
            "meins",
            "netpr",
            "peinh",
            "eindt",
            "etens",
            "ebtyp"
        ]

        validateSection(
            item,
            "purchaseOrderConfirmation.items[${index}]",
            requiredItemFields
        )

        if (!(item.ebelp.toString() ==~ /\d{5}/)) {
            throw new IllegalArgumentException(
                "Field ebelp at item index ${index} must contain exactly 5 digits."
            )
        }

        BigDecimal menge
        BigDecimal netpr
        BigDecimal peinh

        try {
            menge = new BigDecimal(
                item.menge.toString()
            )

            netpr = new BigDecimal(
                item.netpr.toString()
            )

            peinh = new BigDecimal(
                item.peinh.toString()
            )
        } catch (Exception ignored) {
            throw new IllegalArgumentException(
                "Fields menge, netpr, and peinh must contain valid numeric values at item index ${index}."
            )
        }

        if (menge <= 0) {
            throw new IllegalArgumentException(
                "Field menge must be greater than zero at item index ${index}."
            )
        }

        if (netpr <= 0) {
            throw new IllegalArgumentException(
                "Field netpr must be greater than zero at item index ${index}."
            )
        }

        if (peinh <= 0) {
            throw new IllegalArgumentException(
                "Field peinh must be greater than zero at item index ${index}."
            )
        }
    }

    String normalizedBody = JsonOutput.prettyPrint(
        JsonOutput.toJson(payload)
    )

    String originalPayloadSha256 =
        calculateSha256(normalizedBody)

    message.setProperty(
        "messageId",
        messageId
    )

    message.setProperty(
        "ebeln",
        ebeln
    )

    message.setProperty(
        "lifnr",
        lifnr
    )

    message.setProperty(
        "confirmationReference",
        confirmationReference
    )

    message.setProperty(
        "itemCount",
        items.size().toString()
    )

    message.setProperty(
        "originalPayloadSha256",
        originalPayloadSha256
    )

    message.setProperty(
        "pgpSenderUserId",
        "F7 Sender B2B Signing"
    )

    message.setProperty(
        "pgpRecipientUserId",
        "F7 Supplier B2B Encryption"
    )

    message.setProperty(
        "validatedAt",
        Instant.now().toString()
    )

    message.setBody(normalizedBody)

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}


def validateSection(
    def section,
    String sectionName,
    List<String> requiredFields
) {

    if (!(section instanceof Map)) {
        throw new IllegalArgumentException(
            "Section ${sectionName} is mandatory and must be a JSON object."
        )
    }

    def missingFields = requiredFields.findAll { field ->

        if (!section.containsKey(field)) {
            return true
        }

        def value = section[field]

        if (value == null) {
            return true
        }

        if (value instanceof List) {
            return value.isEmpty()
        }

        return value.toString().trim().isEmpty()
    }

    if (!missingFields.isEmpty()) {
        throw new IllegalArgumentException(
            "Missing or empty fields in ${sectionName}: ${missingFields.join(', ')}"
        )
    }
}


def String calculateSha256(String content) {

    MessageDigest digest =
        MessageDigest.getInstance("SHA-256")

    byte[] hash = digest.digest(
        content.getBytes("UTF-8")
    )

    return hash.collect { byteValue ->
        String.format(
            "%02x",
            byteValue & 0xff
        )
    }.join()
}