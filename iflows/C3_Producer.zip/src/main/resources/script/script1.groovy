import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

/**
 * ============================================================
 *  C3 - Enriquecimento da Confirmacao de Producao (Producer)
 * ------------------------------------------------------------
 *  Adiciona metadados de rastreamento a mensagem ANTES de
 *  grava-la na fila JMS. Isso permite acompanhar a "jornada"
 *  da mensagem: MES -> Fila -> ERP.
 * ============================================================
 */
def Message processData(Message message) {

    // Le a confirmacao de producao original (do MES)
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)
    def cp = json.confirmacaoProducao

    // Gera metadados de rastreamento
    def idRastreamento = "TRK-" + UUID.randomUUID().toString().substring(0, 8)
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def timestamp = sdf.format(new Date())

    // Monta a mensagem enriquecida
    def enriquecida = [
        rastreamento: [
            idRastreamento    : idRastreamento,
            origem            : "MES",
            statusIntegracao  : "AGUARDANDO_ENTREGA_ERP",
            recebidoEm        : timestamp,
            filaDestino       : "producao_pedidos"
        ],
        confirmacaoProducao: cp
    ]

    // Grava headers/properties uteis para o Consumer e o monitoramento
    message.setHeader("X-Tracking-Id", idRastreamento)
    message.setProperty("idRastreamento", idRastreamento)

    message.setBody(new JsonBuilder(enriquecida).toPrettyString())
    return message
}