import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.Instant

def Message processData(Message message) {

    def reader = message.getBody(java.io.Reader)
    def payload

    try {
        payload = new JsonSlurper().parse(reader)
    } catch (Exception exception) {
        throw new IllegalArgumentException(
            "Invalid JSON payload received for purchase order change."
        )
    }

    if (!(payload instanceof Map)) {
        throw new IllegalArgumentException(
            "The purchase order change payload must be a JSON object."
        )
    }

    def requiredFields = [
        "purchaseOrder",
        "item",
        "material",
        "plant",
        "previousQuantity",
        "newQuantity",
        "previousNetPrice",
        "newNetPrice",
        "currency",
        "deliveryDate",
        "changeReason",
        "changedBy"
    ]

    def missingFields = requiredFields.findAll { field ->
        !payload.containsKey(field) ||
        payload[field] == null ||
        payload[field].toString().trim().isEmpty()
    }

    if (!missingFields.isEmpty()) {
        throw new IllegalArgumentException(
            "Missing or empty mandatory fields: ${missingFields.join(', ')}"
        )
    }

    def previousQuantity
    def newQuantity
    def previousNetPrice
    def newNetPrice

    try {
        previousQuantity =
            new BigDecimal(payload.previousQuantity.toString())

        newQuantity =
            new BigDecimal(payload.newQuantity.toString())

        previousNetPrice =
            new BigDecimal(payload.previousNetPrice.toString())

        newNetPrice =
            new BigDecimal(payload.newNetPrice.toString())
    } catch (Exception ignored) {
        throw new IllegalArgumentException(
            "Quantity and price fields must contain valid numeric values."
        )
    }

    if (newQuantity <= 0) {
        throw new IllegalArgumentException(
            "The new purchase order quantity must be greater than zero."
        )
    }

    if (newNetPrice <= 0) {
        throw new IllegalArgumentException(
            "The new net price must be greater than zero."
        )
    }

    payload.previousQuantity = previousQuantity
    payload.newQuantity = newQuantity
    payload.previousNetPrice = previousNetPrice
    payload.newNetPrice = newNetPrice
    payload.changedAt = Instant.now().toString()
    payload.securityControl = "CSRF_TOKEN_VALIDATED"
    payload.integrationStatus = "PURCHASE_ORDER_CHANGE_ACCEPTED"

    message.setProperty(
        "purchaseOrder",
        payload.purchaseOrder.toString()
    )

    message.setProperty(
        "item",
        payload.item.toString()
    )

    message.setProperty(
        "newQuantity",
        payload.newQuantity.toString()
    )

    message.setProperty(
        "newNetPrice",
        payload.newNetPrice.toString()
    )

    message.setBody(
        JsonOutput.prettyPrint(
            JsonOutput.toJson(payload)
        )
    )

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}