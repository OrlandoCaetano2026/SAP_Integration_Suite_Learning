import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Supplier confirmation event payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)

    List<String> mandatoryEventFields = [
        "specversion",
        "type",
        "source",
        "id",
        "time",
        "domain",
        "correlationId",
        "data"
    ]

    mandatoryEventFields.each { String field ->
        if (event[field] == null || event[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Mandatory event field '${field}' is missing."
            )
        }
    }

    if (event.specversion != "1.0") {
        throw new IllegalArgumentException(
            "Unsupported specversion '${event.specversion}'."
        )
    }

    if (event.type != "SupplierConfirmationReceived") {
        throw new IllegalArgumentException(
            "Unsupported event type '${event.type}'."
        )
    }

    if (event.domain != "SAP_MM") {
        throw new IllegalArgumentException(
            "Unsupported event domain '${event.domain}'."
        )
    }

    def data = event.data

    List<String> mandatoryDataFields = [
        "EBELN",
        "EBELP",
        "LIFNR",
        "MATNR",
        "WERKS",
        "MENGE",
        "MEINS",
        "confirmationType",
        "confirmedDeliveryDate",
        "processingMode"
    ]

    mandatoryDataFields.each { String field ->
        if (data[field] == null || data[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Mandatory supplier confirmation field '${field}' is missing."
            )
        }
    }

    List<String> supportedModes = [
        "SUCCESS",
        "TEMPORARY_FAILURE",
        "PERMANENT_FAILURE"
    ]

    String processingMode = data.processingMode.toString()

    if (!(processingMode in supportedModes)) {
        throw new IllegalArgumentException(
            "Unsupported processingMode '${processingMode}'."
        )
    }

    message.setProperty("eventId", event.id.toString())
    message.setProperty("correlationId", event.correlationId.toString())
    message.setProperty("processingMode", processingMode)
    message.setProperty("purchaseOrder", data.EBELN.toString())
    message.setProperty("purchaseOrderItem", data.EBELP.toString())
    message.setProperty("supplier", data.LIFNR.toString())
    message.setProperty("plant", data.WERKS.toString())

    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader("X-Correlation-ID", event.correlationId.toString())
    message.setHeader("X-Processing-Mode", processingMode)

    return message
}