import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    String body = message.getBody(String)
    def event = new JsonSlurper().parseText(body)
    def data = event.data

    Object deliveryCountHeader =
        message.getHeader("JMSXDeliveryCount", Object)

    String deliveryCount = deliveryCountHeader != null
        ? deliveryCountHeader.toString()
        : "1"

    def request = [
        requestType: "SUPPLIER_CONFIRMATION_PROCESSING",
        eventId: event.id,
        correlationId: event.correlationId,
        receivedAt: event.time,
        forwardedAt: OffsetDateTime.now(ZoneOffset.UTC).toString(),
        source: event.source,
        domain: event.domain,
        processingMode: data.processingMode,
        deliveryCount: deliveryCount,
        supplierConfirmation: [
            purchaseOrder: data.EBELN,
            purchaseOrderItem: data.EBELP,
            supplier: data.LIFNR,
            material: data.MATNR,
            plant: data.WERKS,
            confirmedQuantity: data.MENGE,
            unit: data.MEINS,
            confirmationType: data.confirmationType,
            confirmedDeliveryDate: data.confirmedDeliveryDate
        ]
    ]

    message.setBody(
        JsonOutput.prettyPrint(
            JsonOutput.toJson(request)
        )
    )

    message.setHeader("Content-Type", "application/json")
    message.setHeader("Accept", "application/json")
    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader(
        "X-Correlation-ID",
        event.correlationId.toString()
    )
    message.setHeader(
        "X-Processing-Mode",
        data.processingMode.toString()
    )
    message.setHeader("X-Delivery-Count", deliveryCount)

    return message
}