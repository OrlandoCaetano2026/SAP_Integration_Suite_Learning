import com.sap.gateway.ip.core.customdev.util.Message
import java.nio.charset.StandardCharsets
import java.util.Base64

def Message processData(Message message) {
    String signedAssertion = message.getBody(String)
    if (!signedAssertion || signedAssertion.trim().isEmpty()) {
        throw new IllegalArgumentException(
            "The signed SAML assertion cannot be empty."
        )
    }
    if (!signedAssertion.contains("<ds:Signature")) {
        throw new SecurityException(
            "The SAML assertion does not contain an XML digital signature."
        )
    }
    String encodedAssertion = Base64
        .getUrlEncoder()
        .withoutPadding()
        .encodeToString(
            signedAssertion.getBytes(StandardCharsets.UTF_8)
        )
    String grantType =
        "urn:ietf:params:oauth:grant-type:saml2-bearer"
    String formBody =
        "grant_type=${urlEncode(grantType)}" +
        "&assertion=${urlEncode(encodedAssertion)}"
    message.setProperty(
        "signedSamlAssertion",
        signedAssertion
    )
    message.setProperty(
        "encodedAssertionLength",
        encodedAssertion.length().toString()
    )
    message.setProperty(
        "oauthGrantType",
        grantType
    )
    message.setProperty(
        "assertionStatus",
        "SIGNED_AND_ENCODED"
    )
    message.setProperty(
        "tokenRequestPrepared",
        "true"
    )
    message.setBody(formBody)
    message.setHeader(
        "CamelHttpMethod",
        "POST"
    )
    message.setHeader(
        "Content-Type",
        "application/x-www-form-urlencoded"
    )
    message.setHeader(
        "Accept",
        "application/json"
    )
    return message
}

def String urlEncode(String value) {
    return java.net.URLEncoder
        .encode(
            value,
            StandardCharsets.UTF_8.name()
        )
        .replace("+", "%20")
}