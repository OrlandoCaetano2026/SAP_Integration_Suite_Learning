import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant

def Message processData(Message message) {
    String requestedOperation = message.getHeader(
        "X-F8-Operation",
        String
    )?.trim()?.toUpperCase()

    String tokenActive = message.getProperty(
        "tokenActive"
    )?.toString()?.trim()

    String tokenIntrospectionStatus = message.getProperty(
        "tokenIntrospectionStatus"
    )?.toString()?.trim()

    String introspectionSubject = message.getProperty(
        "introspectionSubject"
    )?.toString()?.trim()

    String expectedPrincipal = message.getProperty(
        "technicalPrincipal"
    )?.toString()?.trim()

    String availableGroupsValue = message.getProperty(
        "technicalPrincipalGroup"
    )?.toString()?.trim()

    if (!requestedOperation) {
        requestedOperation = "NOT_PROVIDED"
    }

    if (!tokenActive?.equalsIgnoreCase("true")) {
        throw new SecurityException(
            "Authorization cannot continue because the introspected token is not active."
        )
    }

    if (!tokenIntrospectionStatus?.equalsIgnoreCase("VALIDATED")) {
        throw new SecurityException(
            "Authorization cannot continue because token introspection was not validated."
        )
    }

    if (
        !introspectionSubject ||
        introspectionSubject == "NOT_PROVIDED"
    ) {
        throw new SecurityException(
            "Authorization cannot continue because the introspected subject is not available."
        )
    }

    if (
        !expectedPrincipal ||
        !introspectionSubject.equalsIgnoreCase(
            expectedPrincipal
        )
    ) {
        throw new SecurityException(
            "The introspected subject does not match the expected technical principal."
        )
    }

    List<String> availableGroups = parseGroups(
        availableGroupsValue
    )

    String requiredGroup
    String authorizationDecision
    String authorizationReason
    String operationDescription

    switch (requestedOperation) {
        case "READ":
            requiredGroup =
                "F8_PURCHASING_BUYERS"

            operationDescription =
                "Read SAP MM purchase requisitions"

            if (
                availableGroups.contains(
                    "F8_PURCHASING_BUYERS"
                ) ||
                availableGroups.contains(
                    "F8_PURCHASING_MANAGERS"
                )
            ) {
                authorizationDecision =
                    "AUTHORIZED"

                authorizationReason =
                    "The introspected principal belongs to a group authorized to read SAP MM purchase requisitions."
            } else {
                authorizationDecision =
                    "DENIED"

                authorizationReason =
                    "The introspected principal does not belong to a group authorized to read SAP MM purchase requisitions."
            }

            break

        case "APPROVE":
            requiredGroup =
                "F8_PURCHASING_MANAGERS"

            operationDescription =
                "Approve SAP MM purchase requisitions"

            if (
                availableGroups.contains(
                    "F8_PURCHASING_MANAGERS"
                )
            ) {
                authorizationDecision =
                    "AUTHORIZED"

                authorizationReason =
                    "The introspected principal belongs to the purchasing managers group."
            } else {
                authorizationDecision =
                    "DENIED"

                authorizationReason =
                    "The introspected principal belongs to the buyers group but not to the purchasing managers group."
            }

            break

        default:
            requiredGroup =
                "NOT_APPLICABLE"

            operationDescription =
                "Unsupported protected resource operation"

            authorizationDecision =
                "UNSUPPORTED"

            authorizationReason =
                "The requested operation is not supported. Allowed operations are READ and APPROVE."
    }

    message.setProperty(
        "requestedOperation",
        requestedOperation
    )

    message.setProperty(
        "operationDescription",
        operationDescription
    )

    message.setProperty(
        "protectedResource",
        "SAP_MM_PURCHASE_REQUISITIONS"
    )

    message.setProperty(
        "requiredGroup",
        requiredGroup
    )

    message.setProperty(
        "availableGroups",
        availableGroups.isEmpty()
            ? "NONE"
            : availableGroups.join(",")
    )

    message.setProperty(
        "matchedGroup",
        resolveMatchedGroup(
            authorizationDecision,
            requiredGroup,
            availableGroups
        )
    )

    message.setProperty(
        "authorizationDecision",
        authorizationDecision
    )

    message.setProperty(
        "authorizationReason",
        authorizationReason
    )

    message.setProperty(
        "authorizationEvaluatedAt",
        Instant.now().toString()
    )

    message.setProperty(
        "identitySourceForAuthorization",
        "WSO2_TOKEN_INTROSPECTION_SUBJECT"
    )

    message.setProperty(
        "authorizationPolicy",
        "F8B_PURCHASE_REQUISITION_GROUP_POLICY"
    )

    return message
}

def List<String> parseGroups(String groupsValue) {
    if (
        !groupsValue ||
        groupsValue == "NOT_PROVIDED"
    ) {
        return []
    }

    return groupsValue
        .split("[,;|]")
        .collect { group ->
            group.trim().toUpperCase()
        }
        .findAll { group ->
            !group.isEmpty()
        }
}

def String resolveMatchedGroup(
    String authorizationDecision,
    String requiredGroup,
    List<String> availableGroups
) {
    if (
        authorizationDecision != "AUTHORIZED"
    ) {
        return "NONE"
    }

    if (
        availableGroups.contains(
            requiredGroup
        )
    ) {
        return requiredGroup
    }

    if (
        requiredGroup ==
            "F8_PURCHASING_BUYERS" &&
        availableGroups.contains(
            "F8_PURCHASING_MANAGERS"
        )
    ) {
        return "F8_PURCHASING_MANAGERS"
    }

    return "NONE"
}