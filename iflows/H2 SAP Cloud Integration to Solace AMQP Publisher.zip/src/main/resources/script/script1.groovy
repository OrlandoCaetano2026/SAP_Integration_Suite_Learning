import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.UUID

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Purchase Order payload is empty.")
    }

    def input = new JsonSlurper().parseText(body)

    if (!input.purchaseOrder) {
        throw new IllegalArgumentException("Field 'purchaseOrder' is mandatory.")
    }

    if (!input.companyCode) {
        throw new IllegalArgumentException("Field 'companyCode' is mandatory.")
    }

    if (!input.purchasingOrganization) {
        throw new IllegalArgumentException("Field 'purchasingOrganization' is mandatory.")
    }

    if (!input.supplier) {
        throw new IllegalArgumentException("Field 'supplier' is mandatory.")
    }

    if (!input.items || input.items.isEmpty()) {
        throw new IllegalArgumentException("At least one Purchase Order item is mandatory.")
    }

    String eventId = "EVT-H2-" + UUID.randomUUID().toString().toUpperCase()
    String correlationId = "CORR-" + UUID.randomUUID().toString().toUpperCase()
    String timestamp = OffsetDateTime.now(ZoneOffset.UTC).toString()

    def event = [
        specversion: "1.0",
        type: message.getProperty("eventType"),
        source: message.getProperty("eventSource"),
        id: eventId,
        time: timestamp,
        subject: "purchaseorder/${input.purchaseOrder}",
        datacontenttype: "application/json",
        eventVersion: message.getProperty("eventVersion"),
        domain: message.getProperty("eventDomain"),
        correlationId: correlationId,
        data: [
            purchaseOrder: input.purchaseOrder,
            companyCode: input.companyCode,
            purchasingOrganization: input.purchasingOrganization,
            purchasingGroup: input.purchasingGroup,
            supplier: input.supplier,
            plant: input.plant,
            currency: input.currency,
            totalValue: input.totalValue,
            items: input.items
        ]
    ]

    String output = JsonOutput.prettyPrint(JsonOutput.toJson(event))

    message.setBody(output)

    message.setHeader("Content-Type", "application/json")
    message.setHeader("X-Event-ID", eventId)
    message.setHeader("X-Correlation-ID", correlationId)
    message.setHeader("X-Event-Type", message.getProperty("eventType"))

    message.setProperty("eventId", eventId)
    message.setProperty("correlationId", correlationId)
    message.setProperty("eventTimestamp", timestamp)

    return message
}