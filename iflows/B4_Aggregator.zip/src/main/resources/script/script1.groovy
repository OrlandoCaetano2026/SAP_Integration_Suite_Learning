import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)

    // O General Splitter marca o ÚLTIMO item automaticamente
    def isLast = message.getProperty("CamelSplitComplete")
    if (isLast == null) {
        isLast = message.getHeaders().get("CamelSplitComplete")
    }
    isLast = (isLast != null) ? isLast.toString() : "false"

    // Injeta o marcador <ultimo> dentro do <pedido>
    body = body.replaceFirst("</pedido>", "<ultimo>${isLast}</ultimo></pedido>")

    message.setBody(body)
    return message
}