import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    String body = message.getBody(String)
    def event = new JsonSlurper().parseText(body)
    def data = event.data

    String severity = (data.result?.toString() == "BLOCKED") ? "HIGH" : "MEDIUM"

    def alert = [
        alertType: "QUALITY_CRITICAL_RESULT",
        severity: severity,
        raisedBy: "SAP_INTEGRATION_SUITE",
        raisedAt: OffsetDateTime.now(ZoneOffset.UTC).toString(),
        event: [
            eventId: event.id,
            correlationId: event.correlationId,
            eventType: event.type,
            source: event.source,
            domain: event.domain
        ],
        inspection: [
            plant: data.WERKS,
            inspectionLot: data.PRUEFLOS,
            material: data.MATNR,
            inspectionType: data.inspectionType,
            result: data.result,
            qualityScore: data.qualityScore,
            defectCount: data.defectCount
        ],
        recommendedAction: (data.result?.toString() == "BLOCKED")
            ? "Immediate stock block and supplier notification"
            : "Open quality notification and review inspection lot"
    ]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(alert)))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader("X-Correlation-ID", event.correlationId.toString())
    message.setHeader("X-Alert-Severity", severity)

    return message
}