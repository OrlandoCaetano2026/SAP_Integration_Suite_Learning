import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("QM event payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)

    List<String> mandatoryFields = [
        "specversion", "type", "source", "id",
        "time", "domain", "correlationId", "data"
    ]

    mandatoryFields.each { String field ->
        if (event[field] == null || event[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException("Mandatory event field '${field}' is missing.")
        }
    }

    if (event.type != "QualityInspectionResultChanged") {
        throw new IllegalArgumentException("Unsupported event type '${event.type}'.")
    }

    if (event.domain != "SAP_QM") {
        throw new IllegalArgumentException("Unsupported event domain '${event.domain}'.")
    }

    def data = event.data
    String result = data.result?.toString()

    if (!(result in ["REJECTED", "BLOCKED"])) {
        throw new IllegalArgumentException(
            "Non-critical result '${result}' reached the critical consumer. Check topic subscriptions."
        )
    }

    message.setProperty("eventId", event.id.toString())
    message.setProperty("correlationId", event.correlationId.toString())
    message.setProperty("result", result)
    message.setProperty("plant", data.WERKS.toString())

    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader("X-Correlation-ID", event.correlationId.toString())

    return message
}