import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def op = new XmlSlurper().parseText(body)

    def recebidoEm = new Date().format("yyyy-MM-dd'T'HH:mm:ss")
    def idOrdemMES = "MES-${op.numeroOrdem.text()}".toString()

    def sb = new StringBuilder()
    sb.append("<ordemProducaoMES>")
    sb.append("<idOrdemMES>${idOrdemMES}</idOrdemMES>")
    sb.append("<numeroOrdemSAP>${op.numeroOrdem.text()}</numeroOrdemSAP>")
    sb.append("<material>${op.material.text()}</material>")
    sb.append("<descricaoMaterial>${op.descricaoMaterial.text()}</descricaoMaterial>")
    sb.append("<quantidade>${op.quantidade.text()}</quantidade>")
    sb.append("<centroTrabalho>${op.centroTrabalho.text()}</centroTrabalho>")
    sb.append("<statusIntegracao>ORDEM_RECEBIDA_MES</statusIntegracao>")
    sb.append("<recebidoEm>${recebidoEm}</recebidoEm>")
    sb.append("</ordemProducaoMES>")

    message.setBody(sb.toString())
    message.setHeader("Content-Type", "application/xml")

    return message
}