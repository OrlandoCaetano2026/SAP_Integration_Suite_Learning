import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {

    Reader bodyReader = message.getBody(Reader)

    if (bodyReader == null) {
        throw new IllegalArgumentException(
            "The decrypted SAP MM purchase order confirmation payload cannot be empty."
        )
    }

    def payload

    try {
        payload = new JsonSlurper().parse(bodyReader)
    } catch (Exception exception) {
        throw new IllegalArgumentException(
            "The decrypted OpenPGP content is not a valid JSON payload."
        )
    }

    if (!(payload instanceof Map)) {
        throw new IllegalArgumentException(
            "The decrypted purchase order confirmation must be a JSON object."
        )
    }

    validateSection(
        payload.messageHeader,
        "messageHeader",
        [
            "messageId",
            "creationDateTime",
            "senderSystem",
            "receiverSystem",
            "messageType"
        ]
    )

    validateSection(
        payload.purchaseOrderHeader,
        "purchaseOrderHeader",
        [
            "ebeln",
            "bsart",
            "lifnr",
            "ekorg",
            "ekgrp",
            "bukrs",
            "waers"
        ]
    )

    validateSection(
        payload.purchaseOrderConfirmation,
        "purchaseOrderConfirmation",
        [
            "confirmationReference",
            "confirmationDate",
            "confirmationStatus",
            "items"
        ]
    )

    String messageId =
        payload.messageHeader.messageId
            ?.toString()
            ?.trim()

    String messageType =
        payload.messageHeader.messageType
            ?.toString()
            ?.trim()

    String ebeln =
        payload.purchaseOrderHeader.ebeln
            ?.toString()
            ?.trim()

    String lifnr =
        payload.purchaseOrderHeader.lifnr
            ?.toString()
            ?.trim()

    String confirmationReference =
        payload.purchaseOrderConfirmation
            .confirmationReference
            ?.toString()
            ?.trim()

    String confirmationStatus =
        payload.purchaseOrderConfirmation
            .confirmationStatus
            ?.toString()
            ?.trim()

    if (messageType != "PURCHASE_ORDER_CONFIRMATION") {
        throw new IllegalArgumentException(
            "Field messageHeader.messageType must be PURCHASE_ORDER_CONFIRMATION."
        )
    }

    if (!(ebeln ==~ /\d{10}/)) {
        throw new IllegalArgumentException(
            "Field purchaseOrderHeader.ebeln must contain exactly 10 digits."
        )
    }

    if (!(lifnr ==~ /\d{10}/)) {
        throw new IllegalArgumentException(
            "Field purchaseOrderHeader.lifnr must contain exactly 10 digits."
        )
    }

    def items =
        payload.purchaseOrderConfirmation.items

    if (!(items instanceof List) || items.isEmpty()) {
        throw new IllegalArgumentException(
            "Field purchaseOrderConfirmation.items must contain at least one item."
        )
    }

    items.eachWithIndex { item, index ->

        validateSection(
            item,
            "purchaseOrderConfirmation.items[${index}]",
            [
                "ebelp",
                "matnr",
                "werks",
                "lgort",
                "menge",
                "meins",
                "netpr",
                "peinh",
                "eindt",
                "etens",
                "ebtyp"
            ]
        )

        if (!(item.ebelp.toString() ==~ /\d{5}/)) {
            throw new IllegalArgumentException(
                "Field ebelp at item index ${index} must contain exactly 5 digits."
            )
        }

        validatePositiveNumber(
            item.menge,
            "menge",
            index
        )

        validatePositiveNumber(
            item.netpr,
            "netpr",
            index
        )

        validatePositiveNumber(
            item.peinh,
            "peinh",
            index
        )
    }

    String normalizedBody = JsonOutput.prettyPrint(
        JsonOutput.toJson(payload)
    )

    String decryptedPayloadSha256 =
        calculateSha256(normalizedBody)

    message.setProperty(
        "messageId",
        messageId
    )

    message.setProperty(
        "ebeln",
        ebeln
    )

    message.setProperty(
        "lifnr",
        lifnr
    )

    message.setProperty(
        "confirmationReference",
        confirmationReference
    )

    message.setProperty(
        "confirmationStatus",
        confirmationStatus
    )

    message.setProperty(
        "itemCount",
        items.size().toString()
    )

    message.setProperty(
        "decryptedPayloadSha256",
        decryptedPayloadSha256
    )

    message.setProperty(
        "signatureStatus",
        "VALID"
    )

    message.setProperty(
        "encryptionStatus",
        "DECRYPTED"
    )

    message.setProperty(
        "integrityStatus",
        "VALID"
    )

    message.setProperty(
        "messageSecurity",
        "PGP_DECRYPTED_AND_VERIFIED"
    )

    message.setProperty(
        "processedAt",
        Instant.now().toString()
    )

    message.setBody(normalizedBody)

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}


def validateSection(
    def section,
    String sectionName,
    List<String> requiredFields
) {

    if (!(section instanceof Map)) {
        throw new IllegalArgumentException(
            "Section ${sectionName} is mandatory and must be a JSON object."
        )
    }

    def missingFields = requiredFields.findAll { field ->

        if (!section.containsKey(field)) {
            return true
        }

        def value = section[field]

        if (value == null) {
            return true
        }

        if (value instanceof List) {
            return value.isEmpty()
        }

        return value.toString().trim().isEmpty()
    }

    if (!missingFields.isEmpty()) {
        throw new IllegalArgumentException(
            "Missing or empty fields in ${sectionName}: ${missingFields.join(', ')}"
        )
    }
}


def validatePositiveNumber(
    def value,
    String fieldName,
    int itemIndex
) {

    BigDecimal number

    try {
        number = new BigDecimal(
            value.toString()
        )
    } catch (Exception ignored) {
        throw new IllegalArgumentException(
            "Field ${fieldName} must contain a valid numeric value at item index ${itemIndex}."
        )
    }

    if (number <= 0) {
        throw new IllegalArgumentException(
            "Field ${fieldName} must be greater than zero at item index ${itemIndex}."
        )
    }
}


def String calculateSha256(String content) {

    MessageDigest digest =
        MessageDigest.getInstance("SHA-256")

    byte[] hash = digest.digest(
        content.getBytes("UTF-8")
    )

    return hash.collect { byteValue ->
        String.format(
            "%02x",
            byteValue & 0xff
        )
    }.join()
}