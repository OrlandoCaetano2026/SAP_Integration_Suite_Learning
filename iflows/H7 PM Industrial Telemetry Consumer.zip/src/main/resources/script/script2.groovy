import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    def event = new JsonSlurper().parseText(message.getBody(String))
    def d = event.data
    String condition = message.getProperty("condition")?.toString()

    def out = [
        status: "TELEMETRY_PROCESSED",
        eventType: "CONDITION_EVENT",
        condition: condition,
        processedBy: "SAP_INTEGRATION_SUITE",
        processedAt: OffsetDateTime.now(ZoneOffset.UTC).toString(),
        event: [ eventId: event.id, correlationId: event.correlationId, source: event.source, domain: event.domain ],
        telemetry: [
            plant: d.plant, productionLine: d.productionLine, machineId: d.machineId,
            equipmentNumber: d.equipmentNumber, temperatureCelsius: d.temperatureCelsius,
            vibrationMmS: d.vibrationMmS, operatingState: d.operatingState
        ]
    ]
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(out)))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("X-Event-Type", "CONDITION_EVENT")
    message.setHeader("X-Condition", condition)
    return message
}