import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def event = new JsonSlurper().parseText(message.getBody(String))
    def d = event.data
    String mo = message.getProperty("maintenanceOrder")?.toString() ?: "MO-PENDING"

    String html = """<html><body style="font-family:Arial,sans-serif">
<h2 style="color:#c0392b">CRITICAL EQUIPMENT ALERT</h2>
<p>Uma condição crítica foi detectada e uma ordem de manutenção foi criada automaticamente.</p>
<table border="0" cellpadding="6" style="border-collapse:collapse">
<tr><td><b>Ordem de Manutenção</b></td><td>${mo}</td></tr>
<tr><td><b>Equipamento</b></td><td>${d.equipmentNumber}</td></tr>
<tr><td><b>Máquina</b></td><td>${d.machineId}</td></tr>
<tr><td><b>Linha</b></td><td>${d.productionLine}</td></tr>
<tr><td><b>Planta</b></td><td>${d.plant}</td></tr>
<tr><td><b>Temperatura</b></td><td style="color:#c0392b">${d.temperatureCelsius} C (limite 90)</td></tr>
<tr><td><b>Vibração</b></td><td style="color:#c0392b">${d.vibrationMmS} mm/s (limite 7)</td></tr>
<tr><td><b>Estado</b></td><td>CRITICAL</td></tr>
</table>
<p><b>Ação recomendada:</b> intervenção imediata de manutenção.</p>
<p style="color:#888">Notificação automática - SAP Integration Suite - Event Mesh H7</p>
</body></html>"""

    message.setBody(html)
    message.setProperty("mailSubject", "[CRITICAL] Maintenance Order ${mo} - ${d.machineId} / ${d.productionLine}")
    message.setHeader("Content-Type", "text/html")
    return message
}