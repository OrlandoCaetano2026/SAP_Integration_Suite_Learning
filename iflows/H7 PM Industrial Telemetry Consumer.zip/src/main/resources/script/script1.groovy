import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)
    if (!body?.trim()) {
        throw new IllegalArgumentException("Telemetry payload is empty.")
    }
    def event = new JsonSlurper().parseText(body)

    ["specversion","type","source","id","time","domain","correlationId","data"].each { f ->
        if (event[f] == null || event[f].toString().trim().isEmpty()) {
            throw new IllegalArgumentException("Mandatory event field '${f}' is missing.")
        }
    }
    if (event.type != "IndustrialMachineTelemetryReceived") {
        throw new IllegalArgumentException("Unsupported event type '${event.type}'.")
    }
    if (event.domain != "SAP_PM") {
        throw new IllegalArgumentException("Unsupported event domain '${event.domain}'.")
    }

    def d = event.data
    ["plant","productionLine","machineId","equipmentNumber","temperatureCelsius","vibrationMmS","operatingState"].each { f ->
        if (d[f] == null) {
            throw new IllegalArgumentException("Mandatory telemetry field '${f}' is missing.")
        }
    }

    message.setProperty("eventId", event.id.toString())
    message.setProperty("correlationId", event.correlationId.toString())
    message.setProperty("plant", d.plant.toString())
    message.setProperty("productionLine", d.productionLine.toString())
    message.setProperty("machineId", d.machineId.toString())
    message.setProperty("equipmentNumber", d.equipmentNumber.toString())
    message.setProperty("temperature", d.temperatureCelsius.toString())
    message.setProperty("vibration", d.vibrationMmS.toString())

    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader("X-Correlation-ID", event.correlationId.toString())
    return message
}