import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    def event = new JsonSlurper().parseText(message.getBody(String))
    def d = event.data

    String moNumber = "MO-" + System.currentTimeMillis().toString().substring(4)

    def order = [
        status: "MAINTENANCE_ORDER_CREATED",
        eventType: "MAINTENANCE_ORDER",
        priority: "HIGH",
        maintenanceOrder: moNumber,
        orderType: "PM01",
        createdBy: "SAP_INTEGRATION_SUITE",
        createdAt: OffsetDateTime.now(ZoneOffset.UTC).toString(),
        event: [ eventId: event.id, correlationId: event.correlationId ],
        equipment: [
            plant: d.plant, productionLine: d.productionLine, machineId: d.machineId,
            equipmentNumber: d.equipmentNumber, temperatureCelsius: d.temperatureCelsius,
            vibrationMmS: d.vibrationMmS
        ],
        recommendedAction: "Immediate corrective maintenance required"
    ]
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(order)))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("X-Event-Type", "MAINTENANCE_ORDER")
    message.setProperty("maintenanceOrder", moNumber)
    return message
}
