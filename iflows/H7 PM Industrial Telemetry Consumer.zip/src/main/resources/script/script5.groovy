import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)
    def event = new JsonSlurper().parseText(body)
    def d = event.data

    BigDecimal temp = new BigDecimal(d.temperatureCelsius.toString())
    BigDecimal vib  = new BigDecimal(d.vibrationMmS.toString())

    String condition
    if (temp > 90 || vib > 7) {
        condition = "CRITICAL"
    } else if ((temp >= 75 && temp <= 90) || (vib >= 4 && vib <= 7)) {
        condition = "WARNING"
    } else {
        condition = "NORMAL"
    }

    message.setProperty("condition", condition)
    message.setHeader("X-Condition", condition)
    return message
}