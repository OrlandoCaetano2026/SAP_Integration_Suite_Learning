import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def reader = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(reader)

    def mandatoryFields = [
        "idRastreamento",
        "numeroPedido",
        "origem",
        "destino",
        "statusIntegracao",
        "recebidoEm",
        "tentativasReprocessamento",
        "filaDestino"
    ]

    def missingFields = mandatoryFields.findAll { field ->
        !json.containsKey(field) ||
        json[field] == null ||
        json[field].toString().trim().isEmpty()
    }

    if (!missingFields.isEmpty()) {
        throw new IllegalArgumentException(
            "Campos obrigatorios ausentes ou vazios: ${missingFields.join(', ')}"
        )
    }

    def trackingId = json.idRastreamento.toString().trim()

    if (!(trackingId ==~ /^TRK-[A-Za-z0-9-]+$/)) {
        throw new IllegalArgumentException(
            "Formato invalido para idRastreamento. Utilize TRK- seguido do identificador."
        )
    }

    try {
        json.tentativasReprocessamento =
            Integer.parseInt(json.tentativasReprocessamento.toString())
    } catch (Exception ignored) {
        throw new IllegalArgumentException(
            "tentativasReprocessamento deve ser um numero inteiro."
        )
    }

    if (json.tentativasReprocessamento < 0) {
        throw new IllegalArgumentException(
            "tentativasReprocessamento nao pode ser negativo."
        )
    }

    message.setProperty("idRastreamento", trackingId)

    message.setBody(
        JsonOutput.prettyPrint(
            JsonOutput.toJson(json)
        )
    )

    message.setHeader("Content-Type", "application/json")

    return message
}