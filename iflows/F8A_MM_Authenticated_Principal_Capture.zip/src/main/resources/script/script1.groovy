import com.sap.gateway.ip.core.customdev.util.Message
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {

    Map<String, Object> headers =
        message.getHeaders()

    String sapAuthenticatedUserName =
        readHeader(
            headers,
            "SapAuthenticatedUserName"
        )

    String camelAuthenticatedUser =
        readHeader(
            headers,
            "CamelAuthenticatedUser"
        )

    String servletRemoteUser =
        readServletRemoteUser(
            headers
        )

    String claimedPrincipal =
        getFirstAvailableHeader(
            headers,
            [
                "X-Authenticated-User",
                "X-Principal",
                "X-User"
            ]
        )

    String authenticatedPrincipal =
        firstNonEmptyValue(
            [
                sapAuthenticatedUserName,
                camelAuthenticatedUser,
                servletRemoteUser
            ]
        )

    String identitySource
    String principalType
    String principalCaptureStatus

    if (authenticatedPrincipal) {

        identitySource =
            determineIdentitySource(
                sapAuthenticatedUserName,
                camelAuthenticatedUser,
                servletRemoteUser
            )

        principalType =
            classifyPrincipal(
                authenticatedPrincipal
            )

        principalCaptureStatus =
            "AUTHENTICATED_PRINCIPAL_AVAILABLE"

    } else {

        authenticatedPrincipal =
            "NOT_EXPOSED_BY_RUNTIME"

        identitySource =
            "SERVICE_INSTANCE_AUTHENTICATION_CONTEXT"

        principalType =
            "TECHNICAL_CLIENT"

        principalCaptureStatus =
            "AUTHENTICATED_CLIENT_WITHOUT_USER_PRINCIPAL"
    }

    boolean claimedPrincipalProvided =
        claimedPrincipal != null &&
        !claimedPrincipal.trim().isEmpty()

    boolean spoofingAttemptDetected =
        claimedPrincipalProvided

    boolean claimedPrincipalAccepted =
        false

    String principalSha256 =
        authenticatedPrincipal ==
            "NOT_EXPOSED_BY_RUNTIME"
        ? "NOT_CALCULATED"
        : calculateSha256(
            authenticatedPrincipal.toLowerCase()
        )

    List<String> diagnosticHeaderNames =
        getDiagnosticHeaderNames(
            headers
        )

    message.setProperty(
        "authenticatedPrincipal",
        authenticatedPrincipal
    )

    message.setProperty(
        "principalType",
        principalType
    )

    message.setProperty(
        "principalSha256",
        principalSha256
    )

    message.setProperty(
        "identitySource",
        identitySource
    )

    message.setProperty(
        "principalCaptureStatus",
        principalCaptureStatus
    )

    message.setProperty(
        "spoofingAttemptDetected",
        spoofingAttemptDetected.toString()
    )

    message.setProperty(
        "claimedPrincipal",
        claimedPrincipalProvided
            ? claimedPrincipal
            : "NOT_PROVIDED"
    )

    message.setProperty(
        "claimedPrincipalAccepted",
        claimedPrincipalAccepted.toString()
    )

    message.setProperty(
        "diagnosticHeaderNames",
        diagnosticHeaderNames.isEmpty()
            ? "NONE"
            : diagnosticHeaderNames.join(", ")
    )

    message.setProperty(
        "propagationStage",
        "F8A_PRINCIPAL_CAPTURE_BASELINE"
    )

    message.setProperty(
        "propagationMode",
        "NOT_DETERMINED"
    )

    message.setProperty(
        "endToEndPropagation",
        "NOT_EXECUTED"
    )

    message.setProperty(
        "capturedAt",
        Instant.now().toString()
    )

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}


def String readHeader(
    Map<String, Object> headers,
    String headerName
) {

    Object headerValue =
        headers.get(headerName)

    if (headerValue == null) {
        return null
    }

    String normalizedValue =
        headerValue.toString().trim()

    return normalizedValue.isEmpty()
        ? null
        : normalizedValue
}


def String readServletRemoteUser(
    Map<String, Object> headers
) {

    Object servletRequest =
        headers.get("CamelHttpServletRequest")

    if (servletRequest == null) {
        return null
    }

    try {

        String remoteUser =
            servletRequest.getRemoteUser()
                ?.toString()
                ?.trim()

        return remoteUser
            ? remoteUser
            : null

    } catch (Exception ignored) {

        return null
    }
}


def String getFirstAvailableHeader(
    Map<String, Object> headers,
    List<String> headerNames
) {

    for (String headerName : headerNames) {

        String headerValue =
            readHeader(
                headers,
                headerName
            )

        if (headerValue) {
            return headerValue
        }
    }

    return null
}


def String firstNonEmptyValue(
    List<String> values
) {

    return values.find { value ->
        value != null &&
        !value.trim().isEmpty()
    }
}


def String determineIdentitySource(
    String sapAuthenticatedUserName,
    String camelAuthenticatedUser,
    String servletRemoteUser
) {

    if (sapAuthenticatedUserName) {
        return "SAP_AUTHENTICATED_USER_NAME"
    }

    if (camelAuthenticatedUser) {
        return "CAMEL_AUTHENTICATED_USER"
    }

    if (servletRemoteUser) {
        return "HTTPS_SERVLET_REMOTE_USER"
    }

    return "UNKNOWN"
}


def String classifyPrincipal(
    String authenticatedPrincipal
) {

    String normalizedPrincipal =
        authenticatedPrincipal.toLowerCase()

    List<String> technicalPatterns = [
        "client",
        "service",
        "technical",
        "oauth",
        "runtime",
        "integration",
        "sb-"
    ]

    boolean technicalPatternDetected =
        technicalPatterns.any { pattern ->
            normalizedPrincipal.contains(pattern)
        }

    if (technicalPatternDetected) {
        return "TECHNICAL_CLIENT"
    }

    if (
        normalizedPrincipal.contains("@") &&
        normalizedPrincipal.contains(".")
    ) {
        return "HUMAN_USER_CANDIDATE"
    }

    return "AUTHENTICATED_PRINCIPAL"
}


def List<String> getDiagnosticHeaderNames(
    Map<String, Object> headers
) {

    List<String> allowedHeaderNames = [
        "SapAuthenticatedUserName",
        "CamelAuthenticatedUser",
        "CamelHttpMethod",
        "CamelHttpPath",
        "CamelServletContextPath",
        "CamelHttpServletRequest"
    ]

    return allowedHeaderNames.findAll { headerName ->
        headers.containsKey(headerName)
    }
}


def String calculateSha256(
    String content
) {

    MessageDigest digest =
        MessageDigest.getInstance("SHA-256")

    byte[] hash = digest.digest(
        content.getBytes("UTF-8")
    )

    return hash.collect { byteValue ->
        String.format(
            "%02x",
            byteValue & 0xff
        )
    }.join()
}