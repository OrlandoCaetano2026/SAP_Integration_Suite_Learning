import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def vendor = message.getProperty("vendor")
    def material = message.getProperty("material")

    def result = [
        vendorOverride: [
            status: "UNBLOCKED",
            vendor: vendor,
            material: material,
            message: "Vendor block successfully removed by Compliance team"
        ]
    ]

    message.setBody(new JsonBuilder(result).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}