import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def originalPayload = message.getProperty("originalPayload")
    def json = new JsonSlurper().parseText(originalPayload)
    def blockReason = message.getProperty("blockReason")

    def result = [
        purchaseOrder: [
            status: "BLOCKED",
            vendor: json.fornecedor,
            material: json.material,
            blockReason: blockReason
        ]
    ]

    message.setBody(new JsonBuilder(result).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}