import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def response = new XmlSlurper().parseText(body)
    def row = response.Statement1_response.row

    def purchasingBlock = row.purchasing_block.text() == "t"
    def qualityBlock = row.quality_block.text() == "t"
    def blockReason = row.block_reason.text()
    def canCreateOrder = !purchasingBlock && !qualityBlock

    message.setProperty("purchasingBlock", purchasingBlock)
    message.setProperty("qualityBlock", qualityBlock)
    message.setProperty("blockReason", blockReason)
    message.setProperty("canCreateOrder", canCreateOrder)

    return message
}