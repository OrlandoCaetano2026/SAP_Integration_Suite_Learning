import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

/**
 * ============================================================
 *  C1 - Tratamento de Erro (Exception Subprocess) v3
 * ------------------------------------------------------------
 *  Recupera o pacote de erros embutido na mensagem da
 *  excecao. Como o Camel costuma "envelopar" a mensagem com
 *  prefixos (ex: javax.script.ScriptException: ...), este
 *  script EXTRAI o trecho JSON de dentro do texto, procurando
 *  o primeiro '{' e o ultimo '}'.
 * ============================================================
 */
def Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    def msgErro = (ex != null) ? ex.getMessage() : ""
    if (msgErro == null) { msgErro = "" }
    def textoErro = msgErro.toString()

    def ordem = "N/A"
    def totalErros = 0
    def errosDetalhados = []

    // Extrai o trecho JSON de dentro do texto da excecao (robusto)
    try {
        def inicio = textoErro.indexOf('{')
        def fim = textoErro.lastIndexOf('}')
        if (inicio >= 0 && fim > inicio) {
            def jsonPuro = textoErro.substring(inicio, fim + 1)
            def pacote = new JsonSlurper().parseText(jsonPuro)
            if (pacote instanceof Map && pacote.erros != null) {
                ordem = pacote.ordem ?: "N/A"
                totalErros = pacote.totalErros ?: 0
                errosDetalhados = pacote.erros
            }
        }
    } catch (Exception e) {
        // Se nao conseguir extrair, mantem os valores padrao
    }

    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def timestamp = sdf.format(new Date())

    def resposta = [
        status: "ERRO",
        codigo: "VAL-ORDEM-001",
        ordem: ordem,
        mensagem: "Ordem de producao reprovada na validacao",
        totalErros: totalErros as int,
        erros: errosDetalhados,
        tratadoPor: "Exception Subprocess - SAP Integration Suite",
        timestamp: timestamp,
        acaoRecomendada: "Corrigir os campos indicados e reenviar a ordem"
    ]

    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 422)
    return message
}