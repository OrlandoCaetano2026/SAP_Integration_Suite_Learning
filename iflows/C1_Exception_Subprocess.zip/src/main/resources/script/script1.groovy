import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

/**
 * ============================================================
 *  C1 - Validação de Ordem de Produção (v2)
 * ------------------------------------------------------------
 *  Valida múltiplas regras. Se falhar, grava os detalhes em
 *  headers/properties E embute o JSON de erros na própria
 *  mensagem da exceção (para o Exception Subprocess recuperar
 *  de forma robusta).
 * ============================================================
 */
def Message processData(Message message) {

    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)
    def op = json.ordemProducao

    def erros = []

    // Regra 1 - Quantidade a produzir deve ser maior que zero
    if (op.quantidadeProduzir == null || (op.quantidadeProduzir as int) <= 0) {
        erros << [campo: "quantidadeProduzir", regra: "Deve ser maior que zero", valorRecebido: op.quantidadeProduzir]
    }

    // Regra 2 - Centro deve ser válido
    def centrosValidos = ["1000", "2000", "3000"]
    if (!centrosValidos.contains(op.centro?.toString())) {
        erros << [campo: "centro", regra: "Centro inexistente. Validos: 1000, 2000, 3000", valorRecebido: op.centro]
    }

    // Regra 3 - Pelo menos 1 componente
    def qtdComponentes = (op.componentes?.item instanceof List) ? op.componentes.item.size() : 0
    if (qtdComponentes == 0) {
        erros << [campo: "componentes", regra: "A ordem deve conter ao menos 1 componente", valorRecebido: qtdComponentes]
    }

    // Regra 4 - dataInicio nao pode ser posterior a dataFim
    if (op.dataInicio && op.dataFim && op.dataInicio.toString() > op.dataFim.toString()) {
        erros << [campo: "datas", regra: "dataInicio nao pode ser posterior a dataFim", valorRecebido: "${op.dataInicio} > ${op.dataFim}"]
    }

    // Se houver erros, monta um pacote e lanca a excecao
    if (erros.size() > 0) {
        def pacoteErro = [
            ordem: op.numero?.toString() ?: "N/A",
            totalErros: erros.size(),
            erros: erros
        ]
        // Embute o JSON de erros dentro da mensagem da excecao (robusto)
        def pacoteJson = new JsonBuilder(pacoteErro).toString()
        throw new Exception(pacoteJson)
    }

    // Sucesso
    def saida = [
        status: "APROVADO",
        mensagem: "Ordem de producao validada com sucesso",
        ordem: op.numero,
        centro: op.centro,
        quantidadeProduzir: op.quantidadeProduzir,
        totalComponentes: qtdComponentes,
        validadoPor: "SAP Integration Suite - C1"
    ]
    message.setBody(new JsonBuilder(saida).toPrettyString())
    return message
}
