import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

/**
 * ============================================================
 *  C2 - Tratamento de Falha apos Retry (Exception Subprocess)
 * ------------------------------------------------------------
 *  Executa quando o adapter HTTP esgota as tentativas de retry
 *  (3 tentativas) e lanca a excecao. Monta uma resposta de
 *  erro amigavel informando que o sistema destino ficou
 *  indisponivel apos as retentativas.
 * ============================================================
 */
def Message processData(Message message) {

    // Recupera a mensagem tecnica da excecao capturada
    def ex = message.getProperty("CamelExceptionCaught")
    def detalheTecnico = (ex != null) ? ex.getMessage() : "Erro nao identificado"

    // Timestamp do tratamento
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def timestamp = sdf.format(new Date())

    // Monta a resposta de erro amigavel
    def resposta = [
        status: "ERRO",
        codigo: "SVC-503-UNAVAILABLE",
        cenario: "C2 - Retry",
        sistema: "ERP",
        mensagem: "Sistema de destino indisponivel apos 3 tentativas de retry",
        totalTentativas: 3,
        intervaloSegundos: 5,
        tratadoPor: "Exception Subprocess - SAP Integration Suite",
        timestamp: timestamp,
        detalheTecnico: detalheTecnico,
        acaoRecomendada: "A ordem sera encaminhada para reprocessamento posterior"
    ]

    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 503)
    return message
}