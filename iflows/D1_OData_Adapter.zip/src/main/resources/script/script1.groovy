import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)
    def q = json.consultaClientes

    // === Monta o $filter dinamicamente (só o que veio preenchido) ===
    def filtros = []
    if (q.filtros?.pais)          filtros << "Country eq '${q.filtros.pais}'"
    if (q.filtros?.cidade)        filtros << "City eq '${q.filtros.cidade}'"
    if (q.filtros?.nomeContem)    filtros << "contains(CompanyName,'${q.filtros.nomeContem}')"
    if (q.filtros?.tituloContato) filtros << "ContactTitle eq '${q.filtros.tituloContato}'"
    def filterExpr = filtros.join(" and ")

    // === Monta o $select a partir da lista de campos ===
    def selectExpr = (q.camposRetorno && q.camposRetorno.size() > 0) ?
        q.camposRetorno.join(",") : "CustomerID,CompanyName,Country"

    // === Ordenacao e paginacao ===
    def orderbyExpr = "${q.ordenacao?.campo ?: 'CompanyName'} ${q.ordenacao?.direcao ?: 'asc'}"
    def topVal  = (q.paginacao?.limite ?: 10).toString()
    def skipVal = (q.paginacao?.pular ?: 0).toString()

    // Guarda em properties para o OData adapter usar
    message.setProperty("odataFilter", filterExpr)
    message.setProperty("odataSelect", selectExpr)
    message.setProperty("odataOrderby", orderbyExpr)
    message.setProperty("odataTop", topVal)
    message.setProperty("odataSkip", skipVal)

    // Rastreamento
    message.setProperty("solicitante", q.solicitante ?: "N/A")
    return message
}