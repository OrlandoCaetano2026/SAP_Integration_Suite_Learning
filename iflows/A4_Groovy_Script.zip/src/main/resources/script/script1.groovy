import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {

    // 1) LER O PAYLOAD DE ENTRADA (JSON) - via streaming (boa pratica)
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)

    // 2) EXTRAIR OS CAMPOS DO PEDIDO
    def numeroPedido  = json.pedido
    def cliente       = json.cliente
    def material      = json.material
    def quantidade    = json.quantidade as BigDecimal
    def valorUnitario = json.valorUnitario as BigDecimal
    def centro        = json.centro

    // 3) CALCULOS FINANCEIROS
    def valorBruto   = quantidade * valorUnitario
    def aliquotaICMS = 0.18
    def valorICMS    = (valorBruto * aliquotaICMS).setScale(2, BigDecimal.ROUND_HALF_UP)
    def valorTotal   = (valorBruto + valorICMS).setScale(2, BigDecimal.ROUND_HALF_UP)

    // 4) CLASSIFICACAO AUTOMATICA
    def categoria
    def necessitaAprovacao
    if (valorTotal >= 4000) {
        categoria = "ALTO_VALOR"
        necessitaAprovacao = true
    } else if (valorTotal >= 1500) {
        categoria = "MEDIO_VALOR"
        necessitaAprovacao = false
    } else {
        categoria = "BAIXO_VALOR"
        necessitaAprovacao = false
    }

    // 5) GERAR ID DE RASTREAMENTO (UUID)
    def idRastreamento = "TRACK-" + UUID.randomUUID().toString().substring(0, 8)

    // 6) TIMESTAMP FORMATADO
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def dataProcessamento = sdf.format(new Date())

    // 7) GRAVAR HEADERS E PROPERTIES
    message.setHeader("X-Tracking-Id", idRastreamento)
    message.setHeader("X-Processed-By", "Groovy-Script")
    message.setProperty("categoriaPedido", categoria)
    message.setProperty("valorTotalCalculado", valorTotal.toString())

    // 8) MONTAR O JSON DE SAIDA ENRIQUECIDO (via Map - mais seguro)
    def saidaMap = [
        cabecalho: [
            idRastreamento   : idRastreamento,
            processadoPor    : "Groovy Script - SAP Integration Suite",
            dataProcessamento: dataProcessamento,
            statusIntegracao : "PROCESSADO"
        ],
        pedido: [
            numero  : numeroPedido,
            cliente : cliente,
            material: material,
            centro  : centro
        ],
        calculos: [
            quantidade   : quantidade,
            valorUnitario: valorUnitario,
            valorBruto   : valorBruto,
            aliquotaICMS : "18%",
            valorICMS    : valorICMS,
            valorTotal   : valorTotal
        ],
        classificacao: [
            categoria         : categoria,
            necessitaAprovacao: necessitaAprovacao
        ]
    ]

    // 9) DEFINIR O NOVO CORPO DA MENSAGEM
    def saida = new JsonBuilder(saidaMap)
    message.setBody(saida.toPrettyString())

    return message
}