import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.util.UUID

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)
    def nf = json.notaFiscal
    def v = nf.valores
    def execId = UUID.randomUUID().toString()

    // Guarda dados da nota para usar depois (no Aggregator)
    message.setProperty("nfNumero", nf.numero?.toString())
    message.setProperty("nfCliente", nf.cliente?.toString())
    message.setProperty("execId", execId)

    // Monta um XML com a lista de valores (para o Splitter iterar)
    def sb = new StringBuilder()
    sb.append("<notaValores>")
    sb.append("<item><campo>valorBruto</campo><valor>${v.valorBruto}</valor></item>")
    sb.append("<item><campo>valorICMS</campo><valor>${v.valorICMS}</valor></item>")
    sb.append("<item><campo>valorIPI</campo><valor>${v.valorIPI}</valor></item>")
    sb.append("<item><campo>valorLiquido</campo><valor>${v.valorLiquido}</valor></item>")
    sb.append("</notaValores>")

    message.setBody(sb.toString())
    message.setHeader("Content-Type", "application/xml")
    return message
}