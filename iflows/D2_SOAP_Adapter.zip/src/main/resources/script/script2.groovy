import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def parsed = new XmlSlurper().parseText(body)

    def itemNode = (parsed.name() == 'item') ? parsed : parsed.depthFirst().find { it.name() == 'item' }

    def campo = itemNode.campo.text()
    def valor = itemNode.valor.text()

    message.setProperty("campoAtual", campo)
    message.setProperty("valorAtual", valor)

    def payload = """<NumberToWords xmlns="http://www.dataaccess.com/webservicesserver/">
  <ubiNum>${valor}</ubiNum>
</NumberToWords>"""

    message.setBody(payload.toString())
    message.setHeader("Content-Type", "text/xml; charset=UTF-8")
    message.setHeader("SOAPAction", "http://www.dataaccess.com/webservicesserver/NumberToWords")

    return message
}