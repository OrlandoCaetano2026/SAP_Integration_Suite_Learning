import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def resp = new XmlSlurper().parseText(body)
    def porExtenso = resp.depthFirst().find { it.name() == 'NumberToWordsResult' }?.text() ?: "N/A"

    def campo = message.getProperty("campoAtual") ?: "campo"
    def valor = message.getProperty("valorAtual") ?: "0"
    def nfNumero = message.getProperty("nfNumero") ?: "NF"
    def execId = message.getProperty("execId") ?: "SEM-EXEC-ID"

    // Adiciona execId (chave única por chamada) para correlação segura no Aggregator
    def resultado = "<resultado><execId>${execId}</execId><notaId>${nfNumero}</notaId><campo>${campo}</campo><valor>${valor}</valor><porExtenso>${porExtenso.trim()}</porExtenso></resultado>"

    message.setBody(resultado.toString())
    return message
}