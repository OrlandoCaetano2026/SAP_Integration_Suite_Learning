import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Warehouse picking request payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)

    List<String> mandatoryEventFields = [
        "specversion",
        "type",
        "source",
        "id",
        "time",
        "domain",
        "correlationId",
        "data"
    ]

    mandatoryEventFields.each { String field ->
        if (event[field] == null || event[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Mandatory event field '${field}' is missing."
            )
        }
    }

    if (event.specversion != "1.0") {
        throw new IllegalArgumentException(
            "Unsupported specversion '${event.specversion}'."
        )
    }

    if (event.type != "WarehousePickingRequested") {
        throw new IllegalArgumentException(
            "Unsupported event type '${event.type}'."
        )
    }

    if (event.domain != "SAP_WM") {
        throw new IllegalArgumentException(
            "Unsupported event domain '${event.domain}'."
        )
    }

    def data = event.data

    List<String> mandatoryWMFields = [
        "LGNUM",
        "TANUM",
        "VBELN",
        "MATNR",
        "LGTYP",
        "LGPLA",
        "VSOLA",
        "MEINS"
    ]

    mandatoryWMFields.each { String field ->
        if (!data.containsKey(field) || data[field] == null) {
            throw new IllegalArgumentException(
                "Mandatory SAP WM field '${field}' is missing."
            )
        }
    }

    BigDecimal requestedQuantity =
        new BigDecimal(data.VSOLA.toString())

    if (requestedQuantity <= 0) {
        throw new IllegalArgumentException(
            "VSOLA requested quantity must be greater than zero."
        )
    }

    message.setProperty("eventId", event.id.toString())
    message.setProperty("correlationId", event.correlationId.toString())
    message.setProperty("LGNUM", data.LGNUM.toString())
    message.setProperty("TANUM", data.TANUM.toString())
    message.setProperty("VBELN", data.VBELN.toString())
    message.setProperty("MATNR", data.MATNR.toString())

    return message
}