import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Validated picking event is empty.")
    }

    def event = new JsonSlurper().parseText(body)
    def data = event.data

    String workerId =
        message.getProperty("workerId")?.toString()

    String backendName =
        message.getProperty("backendName")?.toString()

    def output = [
        status: "PROCESSED",
        scenario: "H4_COMPETING_CONSUMERS",
        processedBy: workerId,
        backend: backendName,
        processedAt:
            OffsetDateTime.now(ZoneOffset.UTC).toString(),
        event: [
            eventId: event.id,
            correlationId: event.correlationId,
            eventType: event.type,
            source: event.source,
            domain: event.domain
        ],
        pickingRequest: [
            warehouseNumber: data.LGNUM,
            transferOrder: data.TANUM,
            delivery: data.VBELN,
            material: data.MATNR,
            storageType: data.LGTYP,
            storageBin: data.LGPLA,
            requestedQuantity: data.VSOLA,
            unit: data.MEINS
        ]
    ]

    message.setBody(
        JsonOutput.prettyPrint(
            JsonOutput.toJson(output)
        )
    )

    message.setHeader(
        "X-Worker-ID",
        workerId
    )

    message.setHeader(
        "X-Event-ID",
        event.id.toString()
    )

    message.setHeader(
        "X-Correlation-ID",
        event.correlationId.toString()
    )

    return message
}