import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)
    def po = json.purchaseOrder
    message.setProperty("ebeln", po.header.ebeln?.toString())
    message.setProperty("messageFunction", po.header.messageFunction?.toString())
    message.setProperty("bodyOriginal", body)
    message.setBody(body)
    return message
}