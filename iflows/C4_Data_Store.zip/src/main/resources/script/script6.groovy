import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def ebeln = message.getProperty("ebeln")
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")

    def resposta = [
        status: "REJECTED",
        codigo: "DEDUP-409",
        pedido: ebeln,
        mensagem: "Pedido duplicado - ja foi processado anteriormente",
        acao: "IGNORADO_POR_IDEMPOTENCIA",
        rejeitadoEm: sdf.format(new Date())
    ]
    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 409)
    return message
}
