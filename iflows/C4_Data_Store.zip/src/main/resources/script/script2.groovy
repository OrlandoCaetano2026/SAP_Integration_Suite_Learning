import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Header CORRETO que o Data Store Get preenche: 'true' ou 'false'
    def encontrado = message.getHeaders().get("SAP_DataStoreEntryFound")

    def existe = (encontrado != null && encontrado.toString().equalsIgnoreCase("true")) ? "SIM" : "NAO"

    def messageFunction = message.getProperty("messageFunction")?.toString() ?: "009"
    def decisao
    if (messageFunction == "004") {
        decisao = (existe == "SIM") ? "UPDATE" : "NEW"
    } else {
        decisao = (existe == "SIM") ? "DUPLICATE" : "NEW"
    }
    message.setProperty("pedidoExiste", existe)
    message.setProperty("decisao", decisao)
    return message
}