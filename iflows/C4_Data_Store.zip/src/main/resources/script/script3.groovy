import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def ebeln = message.getProperty("ebeln")
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")

    def resposta = [
        status: "PROCESSED",
        codigo: "DEDUP-201",
        pedido: ebeln,
        mensagem: "Pedido novo processado e registrado com sucesso",
        acao: "GRAVADO_NO_DATA_STORE",
        processadoEm: sdf.format(new Date())
    ]
    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 201)
    return message
}
