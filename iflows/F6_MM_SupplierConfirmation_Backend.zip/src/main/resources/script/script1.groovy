import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper
import java.time.Instant

def Message processData(Message message) {

    String body = message.getBody(String)

    String contentType =
        message.getHeader("Content-Type", String) ?: ""

    if (!body || body.trim().isEmpty()) {
        throw new IllegalArgumentException(
            "Supplier confirmation payload cannot be empty."
        )
    }

    String payloadFormat
    String supplierId
    String purchaseOrder

    if (
        contentType.toLowerCase().contains("json") ||
        body.trim().startsWith("{")
    ) {

        payloadFormat = "JSON"

        def payload

        try {
            payload = new JsonSlurper().parseText(body)
        } catch (Exception exception) {
            throw new IllegalArgumentException(
                "Invalid JSON supplier confirmation payload."
            )
        }

        if (!(payload instanceof Map)) {
            throw new IllegalArgumentException(
                "The JSON supplier confirmation must be an object."
            )
        }

        supplierId =
            payload.supplier?.supplierId
                ?.toString()
                ?.trim()

        purchaseOrder =
            payload.purchaseOrder
                ?.toString()
                ?.trim()

    } else if (
        contentType.toLowerCase().contains("xml") ||
        body.trim().startsWith("<")
    ) {

        payloadFormat = "XML"

        def payload

        try {
            payload = new XmlSlurper(
                false,
                false
            ).parseText(body)
        } catch (Exception exception) {
            throw new IllegalArgumentException(
                "Invalid XML supplier confirmation payload."
            )
        }

        supplierId =
            payload.supplier.supplierId
                .text()
                ?.trim()

        purchaseOrder =
            payload.purchaseOrder
                .text()
                ?.trim()

    } else {
        throw new IllegalArgumentException(
            "Unsupported payload format. Use JSON or XML."
        )
    }

    if (!supplierId) {
        throw new IllegalArgumentException(
            "Field supplierId is mandatory."
        )
    }

    if (!purchaseOrder) {
        throw new IllegalArgumentException(
            "Field purchaseOrder is mandatory."
        )
    }

    if (!(purchaseOrder ==~ /\d{10}/)) {
        throw new IllegalArgumentException(
            "Field purchaseOrder must contain exactly 10 digits."
        )
    }

    message.setProperty(
        "supplierId",
        supplierId
    )

    message.setProperty(
        "purchaseOrder",
        purchaseOrder
    )

    message.setProperty(
        "payloadFormat",
        payloadFormat
    )

    message.setProperty(
        "securityValidation",
        "APIM_THREAT_PROTECTION_PASSED"
    )

    message.setProperty(
        "processedAt",
        Instant.now().toString()
    )

    return message
}