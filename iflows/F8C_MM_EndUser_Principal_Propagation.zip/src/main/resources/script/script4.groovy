import com.sap.gateway.ip.core.customdev.util.Message
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

def Message processData(Message message) {
    String accessToken = message.getProperty(
        "internalAccessToken"
    )?.toString()?.trim()

    if (
        !accessToken ||
        accessToken == "NOT_AVAILABLE"
    ) {
        throw new SecurityException(
            "The internal access token is not available for introspection."
        )
    }

    String formBody =
        "token=" +
        URLEncoder.encode(
            accessToken,
            StandardCharsets.UTF_8.name()
        )

    message.setBody(formBody)

    message.setHeader(
        "CamelHttpMethod",
        "POST"
    )

    message.setHeader(
        "Content-Type",
        "application/x-www-form-urlencoded"
    )

    message.setHeader(
        "Accept",
        "application/json"
    )

    message.setProperty(
        "tokenIntrospectionStatus",
        "REQUEST_PREPARED"
    )

    message.setProperty(
        "introspectionRequestPrepared",
        "true"
    )

    return message
}