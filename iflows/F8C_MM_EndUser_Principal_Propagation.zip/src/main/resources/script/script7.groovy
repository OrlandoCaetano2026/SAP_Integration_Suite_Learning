import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.util.Base64
import java.nio.charset.StandardCharsets
import java.time.Instant

def Message processData(Message message) {
    String authorizationHeader = message.getHeader(
        "Authorization",
        String
    )?.trim()

    if (!authorizationHeader || !authorizationHeader.toLowerCase().startsWith("bearer ")) {
        throw new SecurityException(
            "No XSUAA Bearer token was forwarded by the Approuter. The Authorization header is missing or malformed."
        )
    }

    String jwtToken = authorizationHeader.substring(7).trim()
    String[] jwtParts = jwtToken.split("\\.")

    if (jwtParts.length < 2) {
        throw new SecurityException(
            "The forwarded token does not have a valid JWT structure."
        )
    }

    String jwtPayloadJson = decodeBase64Url(jwtParts[1])
    def jwtPayload = new JsonSlurper().parseText(jwtPayloadJson)

    String issuer = jwtPayload.iss?.toString()?.trim()
    String expectedIssuerFragment = "authentication.us10.hana.ondemand.com"

    if (!issuer || !issuer.contains(expectedIssuerFragment)) {
        throw new SecurityException(
            "The JWT issuer is not from the expected XSUAA identity zone: ${issuer}"
        )
    }

    Long expirationEpoch = jwtPayload.exp instanceof Number
        ? ((Number) jwtPayload.exp).longValue()
        : null

    if (expirationEpoch == null) {
        throw new SecurityException(
            "The JWT does not contain a valid expiration claim."
        )
    }

    long currentEpoch = Instant.now().getEpochSecond()

    if (currentEpoch >= expirationEpoch) {
        throw new SecurityException(
            "The forwarded JWT has already expired."
        )
    }

    String realUserEmail = jwtPayload.email?.toString()?.trim()
    String realUserName = jwtPayload.user_name?.toString()?.trim()
    String givenName = jwtPayload.given_name?.toString()?.trim()
    String familyName = jwtPayload.family_name?.toString()?.trim()
    String subjectIdentifier = realUserEmail ?: realUserName

    if (!subjectIdentifier) {
        throw new SecurityException(
            "The JWT does not contain an email or user_name claim to identify the real user."
        )
    }

    List<String> scopes = []
    if (jwtPayload.scope instanceof List) {
        scopes = jwtPayload.scope.collect { it.toString() }
    }

    List<String> groupNames = scopes
        .findAll { it.contains(".") }
        .collect { it.substring(it.lastIndexOf(".") + 1) }

    message.setProperty("realUserSubject", subjectIdentifier)
    message.setProperty("realUserEmail", realUserEmail ?: "NOT_PROVIDED")
    message.setProperty("realUserGivenName", givenName ?: "NOT_PROVIDED")
    message.setProperty("realUserFamilyName", familyName ?: "NOT_PROVIDED")
    message.setProperty("realUserScopes", scopes.isEmpty() ? "NONE" : scopes.join(","))
    message.setProperty("realUserGroups", groupNames.isEmpty() ? "NONE" : groupNames.join(","))
    message.setProperty("jwtIssuer", issuer)
    message.setProperty("jwtClientId", jwtPayload.client_id?.toString()?.trim() ?: "NOT_PROVIDED")
    message.setProperty("jwtExpirationEpoch", expirationEpoch.toString())
    message.setProperty("principalCaptureSource", "XSUAA_JWT_BEARER_EXCHANGED_BY_DESTINATION")
    message.setProperty("propagationMode", "END_USER_PRINCIPAL_PROPAGATION")
    message.setProperty("messageLevelSecurityStatus", "JWT_CLAIMS_VALIDATED")

    return message
}

def String decodeBase64Url(String input) {
    String normalized = input
        .replace('-', '+')
        .replace('_', '/')

    int paddingNeeded = (4 - (normalized.length() % 4)) % 4
    normalized = normalized + ("=" * paddingNeeded)

    byte[] decodedBytes = Base64.getDecoder().decode(normalized)
    return new String(decodedBytes, StandardCharsets.UTF_8)
}