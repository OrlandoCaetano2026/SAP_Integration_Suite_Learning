import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant

def Message processData(Message message) {
    String requestedOperation = message.getHeader(
        "X-F8-Operation",
        String
    )?.trim()?.toUpperCase()

    String tokenActive = message.getProperty(
        "tokenActive"
    )?.toString()?.trim()

    String tokenIntrospectionStatus = message.getProperty(
        "tokenIntrospectionStatus"
    )?.toString()?.trim()

    String introspectionSubject = message.getProperty(
        "introspectionSubject"
    )?.toString()?.trim()

    String expectedPrincipal = message.getProperty(
        "realUserSubject"
    )?.toString()?.trim()

    String availableGroupsValue = message.getProperty(
        "realUserGroups"
    )?.toString()?.trim()

    if (!requestedOperation) {
        requestedOperation = "NOT_PROVIDED"
    }

    if (!tokenActive?.equalsIgnoreCase("true")) {
        throw new SecurityException(
            "Authorization cannot continue because the introspected token is not active."
        )
    }

    if (!tokenIntrospectionStatus?.equalsIgnoreCase("VALIDATED")) {
        throw new SecurityException(
            "Authorization cannot continue because token introspection was not validated."
        )
    }

    if (
        !introspectionSubject ||
        introspectionSubject == "NOT_PROVIDED"
    ) {
        throw new SecurityException(
            "Authorization cannot continue because the introspected subject is not available."
        )
    }

    if (
        !expectedPrincipal ||
        !introspectionSubject.equalsIgnoreCase(
            expectedPrincipal
        )
    ) {
        throw new SecurityException(
            "The introspected subject does not match the expected end-user principal."
        )
    }

    List<String> availableGroups = parseGroups(
        availableGroupsValue
    )

    String requiredGroup
    String authorizationDecision
    String authorizationReason
    String operationDescription

    switch (requestedOperation) {
        case "READ":
            requiredGroup =
                "F8_Purchasing_Buyers"

            operationDescription =
                "Read SAP MM purchase requisitions"

            if (
                containsGroup(availableGroups, "Buyer") ||
                containsGroup(availableGroups, "Manager")
            ) {
                authorizationDecision =
                    "AUTHORIZED"

                authorizationReason =
                    "The authenticated end user belongs to a group authorized to read SAP MM purchase requisitions."
            } else {
                authorizationDecision =
                    "DENIED"

                authorizationReason =
                    "The authenticated end user does not belong to a group authorized to read SAP MM purchase requisitions."
            }

            break

        case "APPROVE":
            requiredGroup =
                "F8_Purchasing_Managers"

            operationDescription =
                "Approve SAP MM purchase requisitions"

            if (containsGroup(availableGroups, "Manager")) {
                authorizationDecision =
                    "AUTHORIZED"

                authorizationReason =
                    "The authenticated end user belongs to the purchasing managers group."
            } else {
                authorizationDecision =
                    "DENIED"

                authorizationReason =
                    "The authenticated end user does not belong to the purchasing managers group."
            }

            break

        default:
            requiredGroup =
                "NOT_APPLICABLE"

            operationDescription =
                "Unsupported protected resource operation"

            authorizationDecision =
                "UNSUPPORTED"

            authorizationReason =
                "The requested operation is not supported. Allowed operations are READ and APPROVE."
    }

    message.setProperty(
        "requestedOperation",
        requestedOperation
    )

    message.setProperty(
        "operationDescription",
        operationDescription
    )

    message.setProperty(
        "protectedResource",
        "SAP_MM_PURCHASE_REQUISITIONS"
    )

    message.setProperty(
        "requiredGroup",
        requiredGroup
    )

    message.setProperty(
        "availableGroups",
        availableGroups.isEmpty()
            ? "NONE"
            : availableGroups.join(",")
    )

    message.setProperty(
        "matchedGroup",
        authorizationDecision == "AUTHORIZED"
            ? requiredGroup
            : "NONE"
    )

    message.setProperty(
        "authorizationDecision",
        authorizationDecision
    )

    message.setProperty(
        "authorizationReason",
        authorizationReason
    )

    message.setProperty(
        "authorizationEvaluatedAt",
        Instant.now().toString()
    )

    message.setProperty(
        "identitySourceForAuthorization",
        "XSUAA_JWT_END_USER_PRINCIPAL"
    )

    message.setProperty(
        "authorizationPolicy",
        "F8C_PURCHASE_REQUISITION_GROUP_POLICY"
    )

    return message
}

def List<String> parseGroups(String groupsValue) {
    if (
        !groupsValue ||
        groupsValue == "NOT_PROVIDED" ||
        groupsValue == "NONE"
    ) {
        return []
    }

    return groupsValue
        .split("[,;|]")
        .collect { group ->
            group.trim()
        }
        .findAll { group ->
            !group.isEmpty()
        }
}

def boolean containsGroup(List<String> groups, String keyword) {
    return groups.any { group ->
        group.toLowerCase().contains(keyword.toLowerCase())
    }
}