import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.time.Instant

def Message processData(Message message) {
    Reader responseReader = message.getBody(Reader)

    String responseBody = responseReader != null
        ? responseReader.text
        : null

    if (!responseBody || responseBody.trim().isEmpty()) {
        clearSensitiveToken(message)

        throw new SecurityException(
            "The WSO2 token introspection response cannot be empty."
        )
    }

    def introspectionResponse

    try {
        introspectionResponse = new JsonSlurper().parseText(
            responseBody
        )
    } catch (Exception exception) {
        clearSensitiveToken(message)

        throw new IllegalArgumentException(
            "The WSO2 token introspection response is not valid JSON."
        )
    }

    boolean tokenActive =
        introspectionResponse.active == true ||
        introspectionResponse.active
            ?.toString()
            ?.equalsIgnoreCase("true")

    String tokenType = introspectionResponse.token_type
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String authenticationContext = introspectionResponse.auth
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String clientId = introspectionResponse.client_id
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String audience = introspectionResponse.aud
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String subject = resolveSubject(
        introspectionResponse
    )

    String issuedAt = introspectionResponse.iat
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String notBefore = introspectionResponse.nbf
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    String expiresAt = introspectionResponse.exp
        ?.toString()
        ?.trim() ?: "NOT_PROVIDED"

    if (!tokenActive) {
        clearSensitiveToken(message)

        message.setProperty(
            "tokenIntrospectionStatus",
            "TOKEN_INACTIVE"
        )

        message.setProperty(
            "tokenActive",
            "false"
        )

        message.setProperty(
            "introspectionTokenType",
            tokenType
        )

        message.setProperty(
            "tokenAuthenticationContext",
            authenticationContext
        )

        message.setProperty(
            "introspectionClientId",
            clientId
        )

        message.setProperty(
            "introspectionAudience",
            audience
        )

        message.setProperty(
            "introspectionSubject",
            subject
        )

        message.setProperty(
            "introspectionIssuedAt",
            issuedAt
        )

        message.setProperty(
            "introspectionNotBefore",
            notBefore
        )

        message.setProperty(
            "introspectionExpiresAt",
            expiresAt
        )

        message.setProperty(
            "accessTokenExposed",
            "false"
        )

        throw new SecurityException(
            "The WSO2 introspection endpoint reported an inactive token."
        )
    }

    if (!tokenType.equalsIgnoreCase("Bearer")) {
        clearSensitiveToken(message)

        throw new SecurityException(
            "The introspected token is not a Bearer token."
        )
    }

    if (
        expiresAt != "NOT_PROVIDED" &&
        !isExpirationInFuture(expiresAt)
    ) {
        clearSensitiveToken(message)

        throw new SecurityException(
            "The introspected token has already expired."
        )
    }

    message.setProperty(
        "tokenExchangeStatus",
        "SAML_BEARER_TOKEN_ISSUED_AND_INTROSPECTED"
    )

    message.setProperty(
        "responseCode",
        "200"
    )

    message.setProperty(
        "responseStatusCode",
        "F8B-INTROSPECTION-200"
    )

    message.setProperty(
        "responseMessage",
        "The SAML bearer access token was issued and validated through OAuth token introspection."
    )

    message.setProperty(
        "tokenIntrospectionStatus",
        "VALIDATED"
    )

    message.setProperty(
        "tokenActive",
        "true"
    )

    message.setProperty(
        "introspectionTokenType",
        tokenType
    )

    message.setProperty(
        "tokenAuthenticationContext",
        authenticationContext
    )

    message.setProperty(
        "introspectionClientId",
        clientId
    )

    message.setProperty(
        "introspectionAudience",
        audience
    )

    message.setProperty(
        "introspectionSubject",
        subject
    )

    message.setProperty(
        "introspectionIssuedAt",
        issuedAt
    )

    message.setProperty(
        "introspectionNotBefore",
        notBefore
    )

    message.setProperty(
        "introspectionExpiresAt",
        expiresAt
    )

    message.setProperty(
        "tokenIntrospectedAt",
        Instant.now().toString()
    )

    message.setProperty(
        "accessTokenExposed",
        "false"
    )

    clearSensitiveToken(message)

    message.setHeader(
        "CamelHttpResponseCode",
        200
    )

    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}

def String resolveSubject(def introspectionResponse) {
    List<String> candidates = [
        introspectionResponse.sub
            ?.toString()
            ?.trim(),
        introspectionResponse.username
            ?.toString()
            ?.trim(),
        introspectionResponse.user_name
            ?.toString()
            ?.trim()
    ]

    String subject = candidates.find { candidate ->
        candidate != null &&
        !candidate.isEmpty()
    }

    return subject ?: "NOT_PROVIDED"
}

def boolean isExpirationInFuture(String expirationValue) {
    try {
        long expirationEpoch =
            Long.parseLong(expirationValue)

        long currentEpoch =
            Instant.now().getEpochSecond()

        return expirationEpoch > currentEpoch
    } catch (Exception ignored) {
        return true
    }
}

def void clearSensitiveToken(Message message) {
    message.setProperty(
        "internalAccessToken",
        "REMOVED_AFTER_INTROSPECTION"
    )
}