import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {
    Reader responseReader = message.getBody(Reader)
    String responseBody = responseReader != null
        ? responseReader.text
        : ""
    Integer responseCode = resolveHttpResponseCode(message)

    if (!responseBody || responseBody.trim().isEmpty()) {
        responseBody = "{}"
    }

    def responsePayload

    try {
        responsePayload = new JsonSlurper().parseText(responseBody)
    } catch (Exception ignored) {
        responsePayload = [
            error: "non_json_response",
            error_description: responseBody.take(500)
        ]
    }

    if (responseCode >= 400) {
        String oauthError = responsePayload.error
            ?.toString()
            ?.trim() ?: "oauth_token_exchange_failed"
        String oauthErrorDescription = responsePayload.error_description
            ?.toString()
            ?.trim() ?: "The WSO2 token endpoint rejected the SAML bearer assertion."

        message.setProperty(
            "tokenExchangeStatus",
            "SAML_BEARER_TOKEN_REJECTED"
        )
        message.setProperty(
            "responseCode",
            responseCode.toString()
        )
        message.setProperty(
            "responseStatusCode",
            "F8B-SAML-400"
        )
        message.setProperty(
            "responseMessage",
            "The WSO2 token endpoint rejected the SAML bearer token exchange."
        )
        message.setProperty(
            "oauthError",
            oauthError
        )
        message.setProperty(
            "oauthErrorDescription",
            oauthErrorDescription
        )
        message.setProperty(
            "tokenType",
            "NOT_ISSUED"
        )
        message.setProperty(
            "expiresIn",
            "NOT_PROVIDED"
        )
        message.setProperty(
            "scope",
            "NOT_PROVIDED"
        )
        message.setProperty(
            "internalAccessToken",
            "NOT_AVAILABLE"
        )
        message.setProperty(
            "maskedAccessToken",
            "NOT_ISSUED"
        )
        message.setProperty(
            "accessTokenSha256",
            "NOT_CALCULATED"
        )
        message.setProperty(
            "tokenIssuedAt",
            "NOT_ISSUED"
        )
        message.setProperty(
            "technicalPrincipal",
            "f8.technical.purchasing.user"
        )
        message.setProperty(
            "technicalPrincipalGroup",
            "F8_PURCHASING_BUYERS"
        )
        message.setProperty(
            "tokenIntrospectionStatus",
            "NOT_EXECUTED"
        )
        message.setHeader(
            "CamelHttpResponseCode",
            400
        )
        message.setHeader(
            "Content-Type",
            "application/json"
        )

        return message
    }

    String accessToken = responsePayload.access_token
        ?.toString()
        ?.trim()
    String tokenType = responsePayload.token_type
        ?.toString()
        ?.trim()
    String expiresIn = responsePayload.expires_in
        ?.toString()
        ?.trim()
    String scope = responsePayload.scope
        ?.toString()
        ?.trim()

    if (!accessToken) {
        throw new SecurityException(
            "The WSO2 response does not contain an access token."
        )
    }

    if (!tokenType?.equalsIgnoreCase("Bearer")) {
        throw new SecurityException(
            "The WSO2 response does not contain a Bearer token."
        )
    }

    message.setProperty(
        "tokenExchangeStatus",
        "SAML_BEARER_TOKEN_ISSUED"
    )
    message.setProperty(
        "responseCode",
        "200"
    )
    message.setProperty(
        "responseStatusCode",
        "F8B-SAML-200"
    )
    message.setProperty(
        "responseMessage",
        "The technical user SAML bearer assertion was exchanged for an OAuth access token."
    )
    message.setProperty(
        "oauthError",
        "NONE"
    )
    message.setProperty(
        "oauthErrorDescription",
        "NONE"
    )
    message.setProperty(
        "tokenType",
        tokenType
    )
    message.setProperty(
        "expiresIn",
        expiresIn ?: "NOT_PROVIDED"
    )
    message.setProperty(
        "scope",
        scope ?: "NOT_PROVIDED"
    )
    message.setProperty(
        "internalAccessToken",
        accessToken
    )
    message.setProperty(
        "maskedAccessToken",
        maskToken(accessToken)
    )
    message.setProperty(
        "accessTokenSha256",
        calculateSha256(accessToken)
    )
    message.setProperty(
        "tokenIssuedAt",
        Instant.now().toString()
    )
    message.setProperty(
        "technicalPrincipal",
        "f8.technical.purchasing.user"
    )
    message.setProperty(
        "technicalPrincipalGroup",
        "F8_PURCHASING_BUYERS"
    )
    message.setProperty(
        "tokenIntrospectionStatus",
        "PENDING"
    )
    message.setHeader(
        "CamelHttpResponseCode",
        200
    )
    message.setHeader(
        "Content-Type",
        "application/json"
    )

    return message
}

def Integer resolveHttpResponseCode(Message message) {
    Map<String, Object> headers = message.getHeaders()
    Object responseCode = headers.get(
        "CamelHttpResponseCode"
    )

    if (responseCode == null) {
        return 200
    }

    try {
        return Integer.parseInt(
            responseCode.toString()
        )
    } catch (Exception ignored) {
        return 200
    }
}

def String maskToken(String token) {
    if (token.length() <= 12) {
        return "********"
    }

    return token.substring(0, 8) +
        "-****-****-" +
        token.substring(token.length() - 4)
}

def String calculateSha256(String content) {
    MessageDigest digest = MessageDigest.getInstance(
        "SHA-256"
    )
    byte[] hash = digest.digest(
        content.getBytes("UTF-8")
    )

    return hash.collect { byteValue ->
        String.format(
            "%02x",
            byteValue & 0xff
        )
    }.join()
}