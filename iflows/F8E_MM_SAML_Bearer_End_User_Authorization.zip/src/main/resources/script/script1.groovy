import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

def Message processData(Message message) {
    Instant now = Instant.now()
    Instant notBefore = now.minus(30, ChronoUnit.SECONDS)
    Instant notOnOrAfter = now.plus(5, ChronoUnit.MINUTES)

    String assertionId = "_${UUID.randomUUID().toString()}"
    String issuer = "F8 SAP Integration Suite SAML Assertion Issuer"

    String subject = message.getProperty("realUserSubject")?.toString()?.trim()
    if (!subject) {
        throw new SecurityException("The F8E SAML subject was not determined.")
    }

    String email = message.getProperty("realUserEmail")?.toString()?.trim()
    if (!email) {
        email = "${subject}@example.invalid"
    }

    String groupsProperty = message.getProperty("expectedUserGroups")?.toString()?.trim()
    List<String> groupList = groupsProperty ? groupsProperty.split(",").collect { it.trim() }.findAll { it } : []
    if (groupList.isEmpty()) {
        throw new SecurityException("No lab groups were resolved for the F8E subject.")
    }

    StringBuilder groupsXml = new StringBuilder()
    groupList.each { g ->
        groupsXml.append("            <saml2:AttributeValue xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"xs:string\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">${escapeXml(g)}</saml2:AttributeValue>\n")
    }

    String tokenServiceUrl = "https://aground-carport-backup.ngrok-free.dev/oauth2/token"
    String issueInstant = now.toString()
    String notBeforeValue = notBefore.toString()
    String notOnOrAfterValue = notOnOrAfter.toString()

    String assertion = """<saml2:Assertion xmlns:saml2="urn:oasis:names:tc:SAML:2.0:assertion" ID="${assertionId}" IssueInstant="${issueInstant}" Version="2.0">
    <saml2:Issuer>${escapeXml(issuer)}</saml2:Issuer>
    <saml2:Subject>
        <saml2:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">${escapeXml(subject)}</saml2:NameID>
        <saml2:SubjectConfirmation Method="urn:oasis:names:tc:SAML:2.0:cm:bearer">
            <saml2:SubjectConfirmationData NotOnOrAfter="${notOnOrAfterValue}" Recipient="${escapeXml(tokenServiceUrl)}"/>
        </saml2:SubjectConfirmation>
    </saml2:Subject>
    <saml2:Conditions NotBefore="${notBeforeValue}" NotOnOrAfter="${notOnOrAfterValue}">
        <saml2:AudienceRestriction>
            <saml2:Audience>${escapeXml(tokenServiceUrl)}</saml2:Audience>
        </saml2:AudienceRestriction>
    </saml2:Conditions>
    <saml2:AuthnStatement AuthnInstant="${issueInstant}">
        <saml2:AuthnContext>
            <saml2:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:PreviousSession</saml2:AuthnContextClassRef>
        </saml2:AuthnContext>
    </saml2:AuthnStatement>
    <saml2:AttributeStatement>
        <saml2:Attribute Name="userId">
            <saml2:AttributeValue xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="xs:string" xmlns:xs="http://www.w3.org/2001/XMLSchema">${escapeXml(subject)}</saml2:AttributeValue>
        </saml2:Attribute>
        <saml2:Attribute Name="email">
            <saml2:AttributeValue xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="xs:string" xmlns:xs="http://www.w3.org/2001/XMLSchema">${escapeXml(email)}</saml2:AttributeValue>
        </saml2:Attribute>
        <saml2:Attribute Name="groups">
${groupsXml.toString()}        </saml2:Attribute>
    </saml2:AttributeStatement>
</saml2:Assertion>"""

    message.setProperty("samlAssertionId", assertionId)
    message.setProperty("samlSubject", subject)
    message.setProperty("samlSubjectEmail", email)
    message.setProperty("samlSubjectGroups", groupList.join(","))
    message.setProperty("samlAudience", tokenServiceUrl)
    message.setProperty("samlKeyPairAlias", "f8_saml_bearer_signing")
    message.setProperty("tokenServiceUrl", tokenServiceUrl)
    message.setProperty("propagationMode", "END_USER_SAML_BEARER")
    message.setProperty("assertionStatus", "BUILT_NOT_SIGNED")
    message.setBody(assertion)
    message.setHeader("Content-Type", "application/xml")
    return message
}

def String escapeXml(String value) {
    if (value == null) {
        return ""
    }
    return value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}