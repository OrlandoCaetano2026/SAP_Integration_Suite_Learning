import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    String requestedUser = message.getHeader("X-F8-Test-User", String)?.trim()

    Map<String, Map<String, Object>> allowedUsers = [
        "buyer.user": [
            subject: "buyer.user",
            email: "buyer.user@example.invalid",
            expectedGroups: ["F8_PURCHASING_BUYERS"]
        ],
        "purchasing.manager": [
            subject: "purchasing.manager",
            email: "purchasing.manager@example.invalid",
            expectedGroups: ["F8_PURCHASING_BUYERS", "F8_PURCHASING_MANAGERS"]
        ]
    ]

    if (!requestedUser || !allowedUsers.containsKey(requestedUser)) {
        throw new SecurityException("Unsupported F8E lab test user.")
    }

    message.setProperty("realUserSubject", allowedUsers[requestedUser].subject)
    message.setProperty("realUserEmail", allowedUsers[requestedUser].email)
    message.setProperty("expectedUserGroups", allowedUsers[requestedUser].expectedGroups.join(","))
    message.setProperty("identitySelectionMode", "CONTROLLED_LAB_ALLOWLIST")
    return message
}