import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.time.Instant

def Message processData(Message message) {
    String operation = message.getHeader("X-F8-Operation", String)?.trim()?.toUpperCase()
    if (!operation) {
        operation = "UNKNOWN"
    }

    String accessToken = message.getProperty("internalAccessToken")?.toString()?.trim()
    if (!accessToken || accessToken == "NOT_AVAILABLE") {
        throw new SecurityException("The access token is not available for authorization.")
    }

    // Fonte primaria: claim groups dentro do JWT (se o WSO2 injetar)
    List<String> availableGroups = extractGroupsFromJwt(accessToken)
    String identitySource = "WSO2_JWT_GROUPS_CLAIM"

    // Fallback confiavel: grupos resolvidos server-side pela allowlist (Select_Lab_User)
    if (availableGroups.isEmpty()) {
        String expected = message.getProperty("expectedUserGroups")?.toString()?.trim()
        if (expected) {
            availableGroups = expected.split(",").collect { it.trim() }.findAll { it }
            identitySource = "SERVER_SIDE_ALLOWLIST_GROUPS"
        }
    }

    String principal = message.getProperty("realUserSubject")?.toString()?.trim() ?: ""

    boolean isBuyer = availableGroups.contains("F8_PURCHASING_BUYERS")
    boolean isManager = availableGroups.contains("F8_PURCHASING_MANAGERS")

    String requiredGroup
    String decision
    String matchedGroup = ""
    String operationDescription

    if (operation == "READ") {
        requiredGroup = "F8_PURCHASING_BUYERS"
        operationDescription = "Read SAP MM purchase requisitions"
        if (isBuyer) { decision = "AUTHORIZED"; matchedGroup = "F8_PURCHASING_BUYERS" }
        else { decision = "DENIED" }
    } else if (operation == "APPROVE") {
        requiredGroup = "F8_PURCHASING_MANAGERS"
        operationDescription = "Approve SAP MM purchase requisitions"
        if (isManager) { decision = "AUTHORIZED"; matchedGroup = "F8_PURCHASING_MANAGERS" }
        else { decision = "DENIED" }
    } else {
        requiredGroup = "NONE"
        operationDescription = "Unsupported operation"
        decision = "UNSUPPORTED"
    }

    String authorizationReason
    if (decision == "AUTHORIZED") {
        authorizationReason = "Principal holds the required group ${matchedGroup}."
    } else if (decision == "DENIED") {
        authorizationReason = "Principal lacks the required group ${requiredGroup}."
    } else {
        authorizationReason = "Operation ${operation} is not supported."
    }

    message.setProperty("authorizationDecision", decision)
    message.setProperty("introspectionSubject", principal)
    message.setProperty("identitySourceForAuthorization", identitySource)
    message.setProperty("availableGroups", availableGroups.join(","))
    message.setProperty("requiredGroup", requiredGroup)
    message.setProperty("matchedGroup", matchedGroup)
    message.setProperty("authorizationPolicy", "READ=F8_PURCHASING_BUYERS;APPROVE=F8_PURCHASING_MANAGERS")
    message.setProperty("authorizationReason", authorizationReason)
    message.setProperty("protectedResource", "SAP_MM_PURCHASE_REQUISITION")
    message.setProperty("requestedOperation", operation)
    message.setProperty("operationDescription", operationDescription)
    message.setProperty("authorizationEvaluatedAt", Instant.now().toString())
    return message
}

def List<String> extractGroupsFromJwt(String token) {
    List<String> result = []
    String[] parts = token.split("\\.")
    if (parts.length < 2) {
        return result
    }
    try {
        String payloadJson = new String(
            Base64.getUrlDecoder().decode(padBase64(parts[1])),
            StandardCharsets.UTF_8
        )
        def payload = new JsonSlurper().parseText(payloadJson)
        def groupsClaim = payload.groups
        if (groupsClaim instanceof List) {
            result = groupsClaim.collect { it.toString() }
        } else if (groupsClaim instanceof String) {
            result = groupsClaim.split(",").collect { it.trim() }.findAll { it }
        }
    } catch (Exception ignored) {
        // JWT sem claim groups: segue para o fallback server-side
    }
    return result
}

def String padBase64(String value) {
    int remainder = value.length() % 4
    if (remainder == 0) {
        return value
    }
    return value + ("=" * (4 - remainder))
}