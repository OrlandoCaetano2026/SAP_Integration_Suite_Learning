import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader responseReader = message.getBody(Reader)
    String responseBody = responseReader != null ? responseReader.text : ""

    if (!responseBody || responseBody.trim().isEmpty()) {
        responseBody = "{}"
    }

    def parsed
    try {
        parsed = new JsonSlurper().parseText(responseBody)
    } catch (Exception ignored) {
        throw new SecurityException("The introspection response is not valid JSON.")
    }

    boolean active = (parsed.active == true)
    if (!active) {
        message.setProperty("tokenActive", "false")
        message.setProperty("tokenIntrospectionStatus", "TOKEN_INACTIVE")
        throw new SecurityException("The access token is not active.")
    }

    message.setProperty("tokenActive", "true")
    message.setProperty("tokenIntrospectionStatus", "VALIDATED")
    message.setProperty("introspectionUsername", parsed.username?.toString() ?: "")
    message.setProperty("introspectionScope", parsed.scope?.toString() ?: "")
    return message
}