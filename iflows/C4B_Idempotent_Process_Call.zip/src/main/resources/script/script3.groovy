import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def ebeln = message.getProperty("ebeln")
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def resposta = [
        status: "PROCESSED",
        codigo: "IDEM-201",
        pedido: ebeln,
        mensagem: "Pedido novo processado (exactly-once garantido)",
        acao: "REGISTRADO_NO_IDEMPOTENT_REPOSITORY",
        processadoEm: sdf.format(new Date())
    ]
    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 201)
    return message
}