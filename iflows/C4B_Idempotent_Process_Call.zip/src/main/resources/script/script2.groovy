import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def ebeln = message.getProperty("ebeln")
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def resposta = [
        status: "REJECTED",
        codigo: "IDEM-409",
        pedido: ebeln,
        mensagem: "Pedido duplicado detectado pelo Idempotent Process Call",
        acao: "IGNORADO_EXACTLY_ONCE",
        rejeitadoEm: sdf.format(new Date())
    ]
    message.setBody(new JsonBuilder(resposta).toPrettyString())
    message.setHeader("CamelHttpResponseCode", 409)
    return message
}