import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)
    def po = json.purchaseOrder
    message.setProperty("ebeln", po.header.ebeln?.toString())
    return message
}