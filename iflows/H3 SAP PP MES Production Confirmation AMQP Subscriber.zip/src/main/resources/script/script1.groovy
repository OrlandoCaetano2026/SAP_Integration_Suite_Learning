import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Event payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)

    List<String> mandatoryFields = [
        "specversion",
        "type",
        "source",
        "id",
        "time",
        "subject",
        "datacontenttype",
        "eventVersion",
        "domain",
        "correlationId",
        "data"
    ]

    mandatoryFields.each { String field ->
        if (event[field] == null || event[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Mandatory event field '${field}' is missing."
            )
        }
    }

    if (event.specversion != "1.0") {
        throw new IllegalArgumentException(
            "Unsupported specversion '${event.specversion}'. Expected '1.0'."
        )
    }

    if (event.type != "ProductionOrderConfirmed") {
        throw new IllegalArgumentException(
            "Unsupported event type '${event.type}'."
        )
    }

    if (event.domain != "SAP_PP") {
        throw new IllegalArgumentException(
            "Unsupported event domain '${event.domain}'."
        )
    }

    if (event.source != "MES_SHOP_FLOOR") {
        throw new IllegalArgumentException(
            "Unsupported event source '${event.source}'."
        )
    }

    message.setProperty("eventId", event.id.toString())
    message.setProperty("correlationId", event.correlationId.toString())
    message.setProperty("eventType", event.type.toString())
    message.setProperty("eventSource", event.source.toString())
    message.setProperty("eventDomain", event.domain.toString())
    message.setProperty("eventSubject", event.subject.toString())

    message.setHeader("X-Event-ID", event.id.toString())
    message.setHeader("X-Correlation-ID", event.correlationId.toString())
    message.setHeader("X-Event-Type", event.type.toString())

    return message
}