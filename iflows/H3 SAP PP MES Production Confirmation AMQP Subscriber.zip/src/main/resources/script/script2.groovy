import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Production confirmation payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)
    def data = event.data

    if (data == null) {
        throw new IllegalArgumentException("Event data object is missing.")
    }

    List<String> mandatorySAPFields = [
        "AUFNR",
        "WERKS",
        "VORNR",
        "APLZL",
        "ARBPL",
        "MATNR",
        "LMNGA",
        "MEINH",
        "XMNGA",
        "AUERU",
        "BUDAT",
        "ISDD",
        "ISDZ",
        "IEDD",
        "IEDZ",
        "PERNR",
        "MACHINE_ID"
    ]

    mandatorySAPFields.each { String field ->
        if (!data.containsKey(field) || data[field] == null) {
            throw new IllegalArgumentException(
                "Mandatory SAP PP field '${field}' is missing."
            )
        }
    }

    if (!data.AUFNR.toString().trim()) {
        throw new IllegalArgumentException("AUFNR must not be empty.")
    }

    if (!data.WERKS.toString().trim()) {
        throw new IllegalArgumentException("WERKS must not be empty.")
    }

    if (!data.VORNR.toString().trim()) {
        throw new IllegalArgumentException("VORNR must not be empty.")
    }

    if (!data.ARBPL.toString().trim()) {
        throw new IllegalArgumentException("ARBPL must not be empty.")
    }

    if (!data.MATNR.toString().trim()) {
        throw new IllegalArgumentException("MATNR must not be empty.")
    }

    BigDecimal confirmedQuantity = new BigDecimal(data.LMNGA.toString())
    BigDecimal scrapQuantity = new BigDecimal(data.XMNGA.toString())

    if (confirmedQuantity < 0) {
        throw new IllegalArgumentException(
            "LMNGA confirmed quantity cannot be negative."
        )
    }

    if (scrapQuantity < 0) {
        throw new IllegalArgumentException(
            "XMNGA scrap quantity cannot be negative."
        )
    }

    String finalConfirmation = data.AUERU.toString()

    if (!(finalConfirmation in ["", "X"])) {
        throw new IllegalArgumentException(
            "AUERU must be empty or 'X'."
        )
    }

    message.setProperty("AUFNR", data.AUFNR.toString())
    message.setProperty("WERKS", data.WERKS.toString())
    message.setProperty("VORNR", data.VORNR.toString())
    message.setProperty("APLZL", data.APLZL.toString())
    message.setProperty("ARBPL", data.ARBPL.toString())
    message.setProperty("MATNR", data.MATNR.toString())
    message.setProperty("LMNGA", data.LMNGA.toString())
    message.setProperty("MEINH", data.MEINH.toString())
    message.setProperty("XMNGA", data.XMNGA.toString())
    message.setProperty("AUERU", data.AUERU.toString())
    message.setProperty("MACHINE_ID", data.MACHINE_ID.toString())

    return message
}