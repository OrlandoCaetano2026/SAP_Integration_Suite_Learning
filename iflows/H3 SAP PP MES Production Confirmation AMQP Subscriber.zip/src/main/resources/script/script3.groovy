import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.OffsetDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    String body = message.getBody(String)

    if (!body?.trim()) {
        throw new IllegalArgumentException("Validated event payload is empty.")
    }

    def event = new JsonSlurper().parseText(body)
    def data = event.data

    boolean finalConfirmation = data.AUERU?.toString() == "X"

    def output = [
        status: "PROCESSED",
        processingStatus: "SAP_PP_CONFIRMATION_RECEIVED",
        processedBy: "SAP_INTEGRATION_SUITE",
        processedAt: OffsetDateTime.now(ZoneOffset.UTC).toString(),
        event: [
            eventId: event.id,
            correlationId: event.correlationId,
            eventType: event.type,
            source: event.source,
            domain: event.domain
        ],
        productionConfirmation: [
            productionOrder: data.AUFNR,
            plant: data.WERKS,
            operation: data.VORNR,
            operationSequence: data.APLZL,
            workCenter: data.ARBPL,
            material: data.MATNR,
            confirmedQuantity: data.LMNGA,
            unit: data.MEINH,
            scrapQuantity: data.XMNGA,
            finalConfirmation: finalConfirmation,
            postingDate: data.BUDAT,
            actualStartDate: data.ISDD,
            actualStartTime: data.ISDZ,
            actualEndDate: data.IEDD,
            actualEndTime: data.IEDZ,
            personnelNumber: data.PERNR,
            machineId: data.MACHINE_ID
        ]
    ]

    String outputJson = JsonOutput.prettyPrint(
        JsonOutput.toJson(output)
    )

    message.setBody(outputJson)

    message.setHeader(
        "X-Event-ID",
        event.id.toString()
    )

    message.setHeader(
        "X-Correlation-ID",
        event.correlationId.toString()
    )

    return message
}